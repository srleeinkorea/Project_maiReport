"""Standalone v6.0 formula boundary.

The CLI consumes normalized single-person inputs.  Provider-specific parsing is
in ``device_preprocess.py``.  No database, network, credential, identity, or
clinical label is part of this package.
"""
from __future__ import annotations

import argparse
import json
from math import isfinite
from pathlib import Path
from statistics import median
from typing import Any, Iterable, Mapping


VERSION = "v6.0"
STEP_SCORE = [(0, 35.0), (3000, 47.25), (6000, 57.75), (10000, 68.25), (12000, 70.0), (15000, 66.0), (20000, 58.0)]
ACTION_CREDIT = [(0, 0.0), (3000, 0.35), (6000, 0.65), (10000, 0.95), (12000, 1.0)]
I2_WEIGHTS = {"daily_step_volume": 0.55, "postmeal_activity_timing": 0.20, "inactivity_break_reactivation": 0.15, "movement_distribution": 0.10}


def _finite(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(float(value))


def _number(value: Any, name: str, low: float, high: float) -> float:
    if not _finite(value) or not low <= float(value) <= high:
        raise ValueError(f"{name}_range")
    return float(value)


def _clip(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def _interval(value: Any, name: str, low: float, high: float) -> list[float] | None:
    if value is None:
        return None
    if _finite(value):
        exact = _number(value, name, low, high)
        return [exact, exact]
    if isinstance(value, list) and len(value) == 2:
        left, right = _number(value[0], name, low, high), _number(value[1], name, low, high)
        if left > right:
            raise ValueError(f"{name}_interval")
        return [left, right]
    raise ValueError(f"{name}_shape")


def _curve(value: int, points: list[tuple[int, float]]) -> float:
    if type(value) is not int or value < 0:
        raise ValueError("daily_steps_range")
    for (left_x, left_y), (right_x, right_y) in zip(points, points[1:]):
        if value <= right_x:
            return left_y + (value - left_x) * (right_y - left_y) / (right_x - left_x)
    return points[-1][1]


def calculate_i1(base: Mapping[str, Any]) -> dict[str, Any]:
    """v5.7 base I1, retained unchanged inside v6."""
    mode = base.get("mode")
    if mode == "record_proxy":
        if set(base) != {"mode", "daily_steps"}:
            raise ValueError("i1_record_proxy_shape")
        if base["daily_steps"] is None:
            return {"status": "unknown", "score": None, "score_bounds": None, "score_kind": "record_based_life_margin_proxy"}
        score = round(_curve(base["daily_steps"], STEP_SCORE), 2)
        return {"status": "candidate_low_resolution_life_margin", "score": score, "score_bounds": [score, score], "score_kind": "record_based_life_margin_proxy"}
    expected = {"mode", "timeline_complete", "movement_minutes", "active_partition_count", "partition_count", "activity_concentration", "sleep_shortfall_minutes"}
    if mode != "rich" or set(base) != expected or type(base["timeline_complete"]) is not bool:
        raise ValueError("i1_rich_shape")
    complete = base["timeline_complete"]
    if not complete:
        if any(base[name] is not None for name in expected - {"mode", "timeline_complete", "sleep_shortfall_minutes"}):
            raise ValueError("incomplete_timeline_movement_must_be_null")
        sleep = _interval(base["sleep_shortfall_minutes"], "sleep_shortfall_minutes", 0, 1440)
        return {"status": "candidate_context_only", "score": None, "score_bounds": [35.0, 70.0] if sleep else None, "score_kind": "observed_life_margin_state", "reason": "insufficient_observed_movement_context"}
    movement = _number(base["movement_minutes"], "movement_minutes", 0, 1440)
    parts, active = base["partition_count"], base["active_partition_count"]
    if type(parts) is not int or type(active) is not int or parts < 1 or not 0 <= active <= parts:
        raise ValueError("activity_partition_range")
    concentration = base["activity_concentration"]
    if movement == 0:
        if active != 0 or concentration is not None:
            raise ValueError("zero_movement_partition_state")
        amount = distribution = burden = 0.0
    else:
        concentration = _number(concentration, "activity_concentration", 0, 1)
        amount = _clip(movement / 90)
        distribution = _clip(active / parts) * _clip((1 - concentration) / 0.75)
        burden = 0.5 * (1 - _clip((movement - 240) / 240)) + 0.5 * (1 - _clip((concentration - 0.5) / 0.5))
    sleep = _interval(base["sleep_shortfall_minutes"], "sleep_shortfall_minutes", 0, 1440)
    signals: dict[str, list[float]] = {"movement_amount": [amount, amount], "movement_distribution": [distribution, distribution], "low_burden": [burden, burden]}
    weights = {"movement_amount": 0.15, "movement_distribution": 0.25, "low_burden": 0.25, "sleep_sufficiency": 0.35}
    if sleep is not None:
        signals["sleep_sufficiency"] = sorted(_clip(1 - value / 120) for value in sleep)
    available = [name for name in signals if name in weights]
    total_weight = sum(weights[name] for name in available)
    low = 35 + 55 * sum(weights[name] * signals[name][0] for name in available) / total_weight
    high = 35 + 55 * sum(weights[name] * signals[name][1] for name in available) / total_weight
    cap = 90 if sleep is not None else 82
    bounds = [round(min(low, cap), 2), round(min(high, cap), 2)]
    return {"status": "candidate_life_margin_state" if bounds[0] == bounds[1] and sleep is not None else "candidate_partial_life_margin_state", "score": bounds[0] if bounds[0] == bounds[1] else None, "score_bounds": bounds, "score_kind": "observed_life_margin_state", "evidence_level": "full_context" if sleep is not None else "timeline_without_sleep", "cap": cap}


def calculate_i2(base: Mapping[str, Any]) -> dict[str, Any]:
    expected = {"daily_steps", "post_anchor_action_credit", "inactivity_break_credit", "movement_distribution_credit"}
    if set(base) != expected:
        raise ValueError("i2_shape")
    daily_steps = base["daily_steps"]
    features: dict[str, list[float] | None] = {
        "daily_step_volume": None if daily_steps is None else [_curve(daily_steps, ACTION_CREDIT)] * 2,
        "postmeal_activity_timing": _interval(base["post_anchor_action_credit"], "post_anchor_action_credit", 0, 1),
        "inactivity_break_reactivation": _interval(base["inactivity_break_credit"], "inactivity_break_credit", 0, 1),
        "movement_distribution": _interval(base["movement_distribution_credit"], "movement_distribution_credit", 0, 1),
    }
    available = {name: value for name, value in features.items() if value is not None}
    if not available:
        return {"status": "unknown", "score": None, "score_bounds": None, "available_components": []}
    weight = sum(I2_WEIGHTS[name] for name in available)
    if set(available) == {"daily_step_volume"}:
        cap, evidence = 85.0, "volume_only"
    elif set(available) == set(features):
        cap, evidence = 100.0, "full_context"
    else:
        cap, evidence = max(55 + 45 * weight, 85 if "daily_step_volume" in available else 0), "partial_context"
    bounds = [round(cap * sum(I2_WEIGHTS[name] * values[index] for name, values in available.items()) / weight, 2) for index in (0, 1)]
    return {"status": "candidate_daily_activity_context" if bounds[0] == bounds[1] else "partial_daily_activity_context", "score": bounds[0] if bounds[0] == bounds[1] else None, "score_bounds": bounds, "available_components": sorted(available), "evidence_level": evidence, "evidence_cap": cap}


def calculate_i3(base: Mapping[str, Any]) -> dict[str, Any]:
    expected = {"action_connection_delta", "recorded_volume_direction", "target_channel_comparable", "positive_context_conflict"}
    if set(base) != expected or type(base["target_channel_comparable"]) is not bool or base["positive_context_conflict"] not in {True, False, None}:
        raise ValueError("i3_shape")
    action = _interval(base["action_connection_delta"], "action_connection_delta", -1, 1)
    record = None if base["recorded_volume_direction"] is None else _number(base["recorded_volume_direction"], "recorded_volume_direction", -1, 1)
    if action is not None and not base["target_channel_comparable"]:
        raise ValueError("noncomparable_action_delta")
    action_bounds = None if action is None else [round(50 + max(-35, min(10 if base["positive_context_conflict"] else 35, 20 * value)), 2) for value in action]
    action_score = None if action_bounds is None or action_bounds[0] != action_bounds[1] else action_bounds[0]
    record_score = None if record is None else round(50 + 20 * record, 2)
    primary = "action_connection" if action_score is not None else "recorded_volume" if record_score is not None else "action_connection" if action_bounds is not None else None
    bounds = action_bounds if primary == "action_connection" else None if record_score is None else [record_score, record_score]
    return {"status": "candidate_personal_change" if primary == "action_connection" and bounds[0] == bounds[1] else "candidate_descriptive_record_change" if primary else "unknown", "score": None if bounds is None or bounds[0] != bounds[1] else bounds[0], "score_bounds": bounds, "primary_channel": primary}


def _baseline_signal(current: Any, baseline_values: Iterable[Any], direction: float, fallback_scale: float) -> dict[str, Any]:
    values = [float(value) for value in baseline_values if _finite(value)]
    if not _finite(current) or len(values) < 3 or fallback_scale <= 0:
        return {"status": "blocked", "bounded_signal": None, "robust_z": None, "valid_baseline_days": len(values), "reason": "insufficient_valid_personal_baseline"}
    center = median(values)
    mad = median(abs(value - center) for value in values)
    if mad > 0:
        z = 0.6745 * (float(current) - center) / mad
        scale_source = "baseline_MAD"
    else:
        z = (float(current) - center) / fallback_scale
        scale_source = "bounded_domain_fallback_scale"
    return {"status": "available", "bounded_signal": round(max(-1, min(1, direction * z / 3)), 6), "robust_z": round(z, 6), "baseline_median": round(center, 6), "baseline_mad": round(mad, 6), "valid_baseline_days": len(values), "scale_source": scale_source, "reason": None}


def _modifier(detail: Mapping[str, Any] | None, baseline: Mapping[str, Iterable[Any]] | None, *, kind: str) -> dict[str, Any]:
    detail = detail or {}
    baseline = baseline or {}
    if kind == "sleep":
        if detail.get("status") != "computed":
            return {"status": "blocked", "modifier": 0.0, "reason": "sleep_detail_unavailable"}
        signals = {"sleep_efficiency": _baseline_signal(detail.get("sleep_efficiency_percent"), baseline.get("sleep_efficiency_percent", ()), 1, 5), "sleep_fragmentation": _baseline_signal(detail.get("fragmentation_transitions_per_asleep_hour"), baseline.get("fragmentation_transitions_per_asleep_hour", ()), -1, 1)}
        weights, cap = {"sleep_efficiency": 0.6, "sleep_fragmentation": 0.4}, 8.0
    else:
        if detail.get("status") not in {"computed_hrr_weighted", "computed_duration_only"}:
            return {"status": "blocked", "modifier": 0.0, "reason": "activity_load_unavailable"}
        signals = {"recovery_delta": _baseline_signal(detail.get("recovery_delta_bpm"), baseline.get("recovery_delta_bpm", ()), 1, 10), "hrr_weighted_load": _baseline_signal(detail.get("hrr_weighted_load_minutes"), baseline.get("hrr_weighted_load_minutes", ()), -1, 30)}
        weights, cap = {"recovery_delta": 0.6, "hrr_weighted_load": 0.4}, 6.0
    available = {name: signal["bounded_signal"] for name, signal in signals.items() if signal["status"] == "available"}
    if not available:
        return {"status": "blocked", "modifier": 0.0, "available_components": [], "reason": "no_valid_modifier_component", "signals": signals}
    total = sum(weights[name] for name in available)
    normalized = sum(weights[name] * value for name, value in available.items()) / total
    result = {"status": "available", "modifier": round(cap * max(-1, min(1, normalized)), 4), "available_components": sorted(available), "normalized_signal": round(normalized, 6), "reason": None, "signals": signals}
    if kind == "activity" and detail.get("status") == "computed_duration_only":
        result["duration_only"] = True
        result["reason"] = "hrr_weighted_load_unavailable"
    return result


def _physiology_alignment(hrv: Mapping[str, Any] | None, rhr: Mapping[str, Any] | None) -> dict[str, Any]:
    if not hrv or not rhr or hrv.get("status") != "available" or rhr.get("status") != "available":
        return {"status": "blocked", "state": None, "reason": "hrv_or_rhr_baseline_unavailable"}
    if hrv.get("metric") not in {"rmssd", "sdnn"} or rhr.get("metric") != "rhr":
        return {"status": "blocked", "state": None, "reason": "metric_role_mismatch"}
    if (hrv.get("lane_id"), hrv.get("device"), hrv.get("context")) != (rhr.get("lane_id"), rhr.get("device"), rhr.get("context")):
        return {"status": "blocked", "state": None, "reason": "device_lane_or_context_mismatch"}
    if hrv.get("context") == "unknown" or not _finite(hrv.get("robust_z")) or not _finite(rhr.get("robust_z")):
        return {"status": "blocked", "state": None, "reason": "context_or_baseline_spread_unresolved"}
    hrv_z, rhr_z = float(hrv["robust_z"]), float(rhr["robust_z"])
    if rhr_z >= 1 and hrv_z <= -1:
        state = "concordant_elevated_rhr_reduced_hrv"
    elif rhr_z <= -1 and hrv_z >= 1:
        state = "concordant_reduced_rhr_elevated_hrv"
    elif abs(rhr_z) < 1 and abs(hrv_z) < 1:
        state = "neutral"
    else:
        state = "discordant"
    return {"status": "available", "state": state, "hrv_metric": hrv["metric"], "context": hrv["context"], "hrv_robust_z": hrv_z, "rhr_robust_z": rhr_z, "i1_strain_cap_applied": state == "concordant_elevated_rhr_reduced_hrv", "i3_positive_context_conflict": state == "concordant_elevated_rhr_reduced_hrv"}


def calculate_v6_i1(base: Mapping[str, Any], device: Mapping[str, Any] | None = None) -> dict[str, Any]:
    device = device or {}
    base_result = calculate_i1(base)
    sleep = _modifier(device.get("sleep_detail"), device.get("sleep_baseline"), kind="sleep")
    activity = _modifier(device.get("activity_load"), device.get("activity_baseline"), kind="activity")
    modifier = round(sleep["modifier"] + activity["modifier"], 4)
    enriched = dict(base_result)
    if base_result.get("score") is not None:
        enriched["score"] = round(max(0, min(100, base_result["score"] + modifier)), 2)
    if base_result.get("score_bounds") is not None:
        enriched["score_bounds"] = [round(max(0, min(100, value + modifier)), 2) for value in base_result["score_bounds"]]
    hrv, rhr = device.get("hrv"), device.get("rhr")
    alignment = _physiology_alignment(hrv, rhr)
    if alignment.get("i1_strain_cap_applied"):
        if enriched.get("score") is not None:
            enriched["score"] = min(enriched["score"], 70.0)
        if enriched.get("score_bounds") is not None:
            enriched["score_bounds"] = [min(value, 70.0) for value in enriched["score_bounds"]]
    if modifier or alignment.get("i1_strain_cap_applied"):
        enriched["status"] = "candidate_v6_device_enriched_life_margin"
    return {"v5_7_result": base_result, "v6_0_result": enriched, "device_modifiers": {"sleep": sleep, "activity": activity, "total_modifier": modifier, "physiology_cap_applied": alignment.get("i1_strain_cap_applied", False)}, "device_alignment": alignment}


def calculate_v6_i2(base: Mapping[str, Any]) -> dict[str, Any]:
    result = calculate_i2(base)
    return {"v5_7_result": result, "v6_0_result": result, "device_role": "not_used_construct_mismatch"}


def calculate_v6_i3(base: Mapping[str, Any], device: Mapping[str, Any] | None = None) -> dict[str, Any]:
    device = device or {}
    alignment = _physiology_alignment(device.get("hrv"), device.get("rhr"))
    conflict = base["positive_context_conflict"] is True or alignment.get("i3_positive_context_conflict") is True
    enriched_input = dict(base)
    enriched_input["positive_context_conflict"] = conflict
    return {"v5_7_result": calculate_i3(base), "v6_0_result": calculate_i3(enriched_input), "device_alignment": alignment, "effective_positive_context_conflict": conflict}


def score(payload: Mapping[str, Any]) -> dict[str, Any]:
    if set(payload) - {"formula_version", "inputs", "device"} or payload.get("formula_version") != VERSION:
        raise ValueError("payload_shape")
    inputs = payload.get("inputs")
    if not isinstance(inputs, Mapping) or set(inputs) != {"i1", "i2", "i3"}:
        raise ValueError("inputs_shape")
    device = payload.get("device") or {}
    if not isinstance(device, Mapping):
        raise ValueError("device_shape")
    return {"formula_version": VERSION, "results": {"i1": calculate_v6_i1(inputs["i1"], device), "i2": calculate_v6_i2(inputs["i2"]), "i3": calculate_v6_i3(inputs["i3"], device)}}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    args = parser.parse_args()
    print(json.dumps(score(json.loads(args.input.read_text(encoding="utf-8"))), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
