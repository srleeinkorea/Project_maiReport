"""Standalone v6.0 device-field adapters.

This file is deliberately independent of the maiReport repository.  It accepts
provider-native row dictionaries, keeps the source field names in the output,
and emits the normalized constructs consumed by ``maireport_ops.py``.

It does not authenticate, identify, persist, or assign data to a person.  The
owning service supplies one person's rows and a fixed local timezone.
"""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from io import StringIO
from math import isfinite
from statistics import median
from typing import Any, Iterable, Mapping
from xml.etree.ElementTree import iterparse


KST = timezone(timedelta(hours=9))
APPLE_FIELDS = {
    "step_type": "HKQuantityTypeIdentifierStepCount.value",
    "step_start": "HKQuantityTypeIdentifierStepCount.startDate",
    "step_end": "HKQuantityTypeIdentifierStepCount.endDate",
    "sleep_type": "HKCategoryTypeIdentifierSleepAnalysis.value",
    "sleep_start": "HKCategoryTypeIdentifierSleepAnalysis.startDate",
    "sleep_end": "HKCategoryTypeIdentifierSleepAnalysis.endDate",
    "workout_type": "Workout.workoutActivityType",
    "workout_start": "Workout.startDate",
    "workout_end": "Workout.endDate",
    "workout_duration": "Workout.duration/durationUnit",
    "workout_energy": "Workout.totalEnergyBurned/totalEnergyBurnedUnit",
    "heart_rate": "HKQuantityTypeIdentifierHeartRate.value",
    "resting_heart_rate": "HKQuantityTypeIdentifierRestingHeartRate.value",
    "hrv_sdnn": "HKQuantityTypeIdentifierHeartRateVariabilitySDNN.value",
    "physical_effort": "HKQuantityTypeIdentifierPhysicalEffort.value/unit",
    "heart_rate_recovery_1min": "HKQuantityTypeIdentifierHeartRateRecoveryOneMinute.value",
    "active_energy": "HKQuantityTypeIdentifierActiveEnergyBurned.value",
}
SAMSUNG_FIELDS = {
    "daily_step_value": "com.samsung.shealth.tracker.pedometer_day_summary.step_count",
    "daily_step_day": "com.samsung.shealth.tracker.pedometer_day_summary.day_time",
    "step_start": "com.samsung.health.step_count.start_time",
    "step_end": "com.samsung.health.step_count.end_time",
    "step_value": "com.samsung.health.step_count.count",
    "sleep_stage": "com.samsung.health.sleep_stage.stage",
    "sleep_stage_start": "com.samsung.health.sleep_stage.start_time",
    "sleep_stage_end": "com.samsung.health.sleep_stage.end_time",
    "sleep_start": "com.samsung.health.sleep.start_time",
    "sleep_end": "com.samsung.health.sleep.end_time",
    "sleep_duration": "com.samsung.health.sleep.sleep_duration",
    "workout_start": "com.samsung.health.exercise.start_time",
    "workout_end": "com.samsung.health.exercise.end_time",
    "workout_duration": "com.samsung.health.exercise.duration",
    "workout_mean_hr": "com.samsung.health.exercise.mean_heart_rate",
    "workout_max_hr": "com.samsung.health.exercise.max_heart_rate",
    "workout_calorie": "com.samsung.health.exercise.calorie",
    "workout_type": "com.samsung.health.exercise.exercise_type",
    "workout_id": "com.samsung.health.exercise.datauuid",
    "recovery_start": "com.samsung.shealth.exercise.recovery_heart_rate.start_time",
    "recovery_end": "com.samsung.shealth.exercise.recovery_heart_rate.end_time",
    "recovery_exercise_id": "com.samsung.shealth.exercise.recovery_heart_rate.exercise_id",
    "recovery_elapsed": "com.samsung.shealth.exercise.recovery_heart_rate.<sidecar>.chart_data[].elapsed_time",
    "recovery_hr": "com.samsung.shealth.exercise.recovery_heart_rate.<sidecar>.chart_data[].heart_rate",
    "hrv_rmssd": "com.samsung.health.hrv.rmssd",
    "hrv_sdnn": "com.samsung.health.hrv.sdnn",
    "hrv_start": "com.samsung.health.hrv.start_time",
    "hrv_end": "com.samsung.health.hrv.end_time",
    "hrv_binning_reference": "com.samsung.health.hrv.binning_data",
    "ordinary_hr": "com.samsung.health.heart_rate.heart_rate",
}

APPLE_SLEEP_VALUES = {
    "HKCategoryValueSleepAnalysisInBed": "in_bed",
    "HKCategoryValueSleepAnalysisAwake": "awake",
    "HKCategoryValueSleepAnalysisAsleep": "asleep_unspecified",
    "HKCategoryValueSleepAnalysisAsleepCore": "light",
    "HKCategoryValueSleepAnalysisAsleepDeep": "deep",
    "HKCategoryValueSleepAnalysisAsleepREM": "rem",
    "HKCategoryValueSleepAnalysisAsleepUnspecified": "asleep_unspecified",
}
SAMSUNG_SLEEP_STAGES = {"40001": "awake", "40002": "light", "40003": "deep", "40004": "rem"}
SAMSUNG_RECOVERY_TARGET_MS = 60000
SAMSUNG_RECOVERY_TOLERANCE_MS = 2000


def _number(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if isfinite(result) else None


def _first_present(row: Mapping[str, Any], *names: str) -> Any:
    for name in names:
        if name in row and row[name] not in (None, ""):
            return row[name]
    return None


def _step_value(value: Any) -> int | None:
    number = _number(value)
    if number is None or number < 0 or not number.is_integer():
        return None
    return int(number)


def _parse_apple_time(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip()
    for fmt in ("%Y-%m-%d %H:%M:%S %z", "%Y-%m-%d %H:%M:%S.%f %z"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else None


def _parse_samsung_time(value: Any, offset: Any = None) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip()
    parsed = None
    for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"):
        try:
            parsed = datetime.strptime(text, fmt)
            break
        except ValueError:
            pass
    if parsed is None:
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError:
            return None
    if parsed.tzinfo:
        return parsed
    if isinstance(offset, str) and offset.startswith("UTC") and len(offset) == 8:
        sign = 1 if offset[3] == "+" else -1
        try:
            zone = timezone(sign * timedelta(hours=int(offset[4:6]), minutes=int(offset[6:8])))
        except ValueError:
            zone = KST
    else:
        zone = KST
    return parsed.replace(tzinfo=zone)


def _valid_interval(start: datetime | None, end: datetime | None) -> bool:
    return start is not None and end is not None and end > start


def _minutes(start: datetime, end: datetime) -> float:
    return (end - start).total_seconds() / 60.0


def parse_apple_health_export(xml_text: str) -> dict[str, list[dict[str, Any]]]:
    """Extract raw HealthKit Record and Workout attributes without renaming fields."""
    records: list[dict[str, Any]] = []
    workouts: list[dict[str, Any]] = []
    for _, element in iterparse(StringIO(xml_text), events=("end",)):
        if element.tag == "Record":
            records.append(dict(element.attrib))
        elif element.tag == "Workout":
            workouts.append(dict(element.attrib))
        element.clear()
    return {"records": records, "workouts": workouts}


def parse_samsung_csv(csv_text: str) -> list[dict[str, str]]:
    """Read a Samsung export table, including the optional metadata first row."""
    lines = csv_text.splitlines()
    if len(lines) > 1 and lines[0].count(",") < lines[1].count(","):
        lines = lines[1:]
    return [dict(row) for row in __import__("csv").DictReader(StringIO("\n".join(lines)))]


def normalize_apple_step_rows(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        if row.get("type") != "HKQuantityTypeIdentifierStepCount":
            continue
        start = _parse_apple_time(row.get("startDate"))
        end = _parse_apple_time(row.get("endDate"))
        value = _step_value(row.get("value"))
        if not _valid_interval(start, end) or value is None:
            continue
        output.append({"start": start, "end": end, "steps": value, "source_field": APPLE_FIELDS["step_type"]})
    return sorted(output, key=lambda item: item["start"])


def normalize_samsung_daily_step_rows(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        day_time = _first_present(row, "day_time", "com.samsung.health.step_count.start_time")
        day = _parse_samsung_time(day_time, row.get("time_offset"))
        value = _step_value(_first_present(row, "step_count", "count", "com.samsung.health.step_count.count"))
        if day is not None and value is not None:
            output.append({"day": day.date().isoformat(), "steps": value, "source_field": SAMSUNG_FIELDS["daily_step_value"]})
    return output


def normalize_samsung_step_interval_rows(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        start = _parse_samsung_time(row.get(SAMSUNG_FIELDS["step_start"]), row.get("time_offset"))
        end = _parse_samsung_time(row.get(SAMSUNG_FIELDS["step_end"]), row.get("time_offset"))
        value = _step_value(row.get(SAMSUNG_FIELDS["step_value"]))
        if _valid_interval(start, end) and value is not None:
            output.append({"start": start, "end": end, "steps": value, "source_field": SAMSUNG_FIELDS["step_value"]})
    return sorted(output, key=lambda item: item["start"])


def reconcile_daily_steps(
    *, apple_intervals: Iterable[Mapping[str, Any]] = (), samsung_daily: Iterable[Mapping[str, Any]] = (),
    samsung_intervals: Iterable[Mapping[str, Any]] = (), local_timezone: timezone = KST,
) -> list[dict[str, Any]]:
    """Prefer provider daily summaries; otherwise sum non-overlapping same-day intervals.

    A cross-midnight interval and overlapping intervals are excluded.  They are
    not split or proportionally assigned because that would invent daypart data.
    """
    summary = list(samsung_daily)
    if summary:
        by_day: dict[str, float] = {}
        for row in summary:
            day, value = row.get("day"), _number(row.get("steps"))
            if isinstance(day, str) and value is not None:
                if day in by_day and by_day[day] != value:
                    raise ValueError("conflicting_daily_step_summary")
                by_day[day] = value
        return [{"day": day, "steps": value, "observation": "observed", "source": "samsung_daily_summary"} for day, value in sorted(by_day.items())]
    intervals = list(apple_intervals) + list(samsung_intervals)
    grouped: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for row in intervals:
        start, end = row.get("start"), row.get("end")
        if not isinstance(start, datetime) or not isinstance(end, datetime) or not _valid_interval(start, end):
            continue
        local_start = start.astimezone(local_timezone)
        local_end = end.astimezone(local_timezone)
        if local_start.date() != local_end.date():
            continue
        grouped[local_start.date().isoformat()].append(row)
    output = []
    for day, rows in sorted(grouped.items()):
        unique = {(row["start"], row["end"], row.get("steps")) : row for row in rows}
        ordered = sorted(unique.values(), key=lambda row: row["start"])
        if any(left["end"] > right["start"] for left, right in zip(ordered, ordered[1:])):
            continue
        output.append({"day": day, "steps": sum(float(row["steps"]) for row in ordered), "observation": "observed", "source": "timestamped_intervals"})
    return output


def step_intervals_to_timeline_records(
    step_intervals: Iterable[Mapping[str, Any]], *, local_timezone: timezone = KST
) -> list[dict[str, Any]]:
    """Map valid same-local-day step intervals to observed/movement rows.

    A positive interval is movement for the interval supplied by the provider.
    A zero interval is observed but not movement. This function never extends
    an interval, creates full-day coverage, or treats a missing row as zero.
    """
    output = []
    for row in step_intervals:
        start, end = row.get("start"), row.get("end")
        steps = _step_value(row.get("steps"))
        if not _valid_interval(start, end) or steps is None:
            continue
        if start.astimezone(local_timezone).date() != end.astimezone(local_timezone).date():
            continue
        output.append({"start": start, "end": end, "state": "movement" if steps > 0 else "observed", "source_field": row.get("source_field")})
    return sorted(output, key=lambda row: row["start"])


def normalize_apple_sleep_rows(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        if row.get("type") != "HKCategoryTypeIdentifierSleepAnalysis":
            continue
        stage = APPLE_SLEEP_VALUES.get(str(row.get("value")))
        start = _parse_apple_time(row.get("startDate"))
        end = _parse_apple_time(row.get("endDate"))
        if stage and _valid_interval(start, end):
            output.append({"start": start, "end": end, "stage": stage, "source_field": APPLE_FIELDS["sleep_type"]})
    return sorted(output, key=lambda item: item["start"])


def normalize_samsung_sleep_stage_rows(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        stage = SAMSUNG_SLEEP_STAGES.get(str(row.get("stage")))
        start = _parse_samsung_time(row.get("start_time"), row.get("time_offset"))
        end = _parse_samsung_time(row.get("end_time"), row.get("time_offset"))
        if stage and _valid_interval(start, end):
            output.append({"start": start, "end": end, "stage": stage, "source_field": SAMSUNG_FIELDS["sleep_stage"]})
    return sorted(output, key=lambda item: item["start"])


def _union(intervals: Iterable[tuple[datetime, datetime]]) -> float:
    ordered = sorted((start, end) for start, end in intervals if end > start)
    if not ordered:
        return 0.0
    total = 0.0
    start, end = ordered[0]
    for next_start, next_end in ordered[1:]:
        if next_start <= end:
            end = max(end, next_end)
        else:
            total += _minutes(start, end)
            start, end = next_start, next_end
    return total + _minutes(start, end)


def derive_sleep_detail(stages: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Derive the v6 sleep modifier inputs; overlapping state stages block."""
    valid = []
    seen = set()
    for row in stages:
        start, end, stage = row.get("start"), row.get("end"), row.get("stage")
        key = (start, end, stage, row.get("source_field"))
        if _valid_interval(start, end) and key not in seen:
            seen.add(key)
            valid.append(row)
    valid.sort(key=lambda item: item["start"])
    if not valid:
        return {"status": "blocked", "reason": "no_valid_sleep_stage_interval"}
    state = [row for row in valid if row["stage"] != "in_bed"]
    if any(left["end"] > right["start"] for left, right in zip(state, state[1:])):
        return {"status": "blocked", "reason": "overlapping_sleep_state_intervals"}
    stage_minutes: dict[str, float] = defaultdict(float)
    for row in valid:
        stage_minutes[row["stage"]] += _minutes(row["start"], row["end"])
    asleep_stages = {"light", "deep", "rem", "asleep_unspecified"}
    asleep = sum(stage_minutes[name] for name in asleep_stages)
    window = _minutes(valid[0]["start"], max(row["end"] for row in valid))
    in_bed = _union((row["start"], row["end"]) for row in valid if row["stage"] == "in_bed") or window
    transitions = sum(left["stage"] != right["stage"] for left, right in zip(state, state[1:]))
    return {
        "status": "computed", "reason": None,
        "sleep_window_minutes": round(window, 4), "asleep_minutes": round(asleep, 4),
        "stage_minutes": {key: round(value, 4) for key, value in sorted(stage_minutes.items())},
        "stage_proportions": {key: round(value / asleep, 6) for key, value in sorted(stage_minutes.items()) if key in asleep_stages and asleep > 0},
        "stage_transition_count": transitions,
        "fragmentation_transitions_per_asleep_hour": round(transitions / (asleep / 60), 6) if asleep > 0 else None,
        "in_bed_minutes": round(in_bed, 4),
        "sleep_efficiency_percent": round(100 * asleep / in_bed, 4) if in_bed > 0 else None,
    }


def _normalize_apple_quantity(rows: Iterable[Mapping[str, Any]], record_type: str, source_field: str) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        if row.get("type") != record_type:
            continue
        start = _parse_apple_time(row.get("startDate"))
        end = _parse_apple_time(row.get("endDate")) or start
        value = _number(row.get("value"))
        if start is not None and end is not None and end >= start and value is not None:
            output.append({"start": start, "end": end, "value": value, "unit": row.get("unit"), "source_field": source_field})
    return output


def normalize_apple_workout_rows(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        start = _parse_apple_time(row.get("startDate"))
        end = _parse_apple_time(row.get("endDate"))
        if not _valid_interval(start, end):
            continue
        duration = _number(row.get("duration"))
        unit = str(row.get("durationUnit") or "min")
        if duration is None:
            duration_minutes = _minutes(start, end)
        elif unit in {"min", "m"}:
            duration_minutes = duration
        elif unit in {"sec", "s"}:
            duration_minutes = duration / 60
        elif unit in {"hr", "h"}:
            duration_minutes = duration * 60
        else:
            continue
        if duration_minutes <= 0:
            continue
        output.append({"start": start, "end": end, "duration_minutes": duration_minutes, "workout_type": row.get("workoutActivityType"), "energy_kcal": _number(row.get("totalEnergyBurned")), "source_field": APPLE_FIELDS["workout_start"]})
    return sorted(output, key=lambda item: item["start"])


def normalize_samsung_workout_rows(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        start = _parse_samsung_time(row.get(SAMSUNG_FIELDS["workout_start"]), row.get("time_offset"))
        end = _parse_samsung_time(row.get(SAMSUNG_FIELDS["workout_end"]), row.get("time_offset"))
        if not _valid_interval(start, end):
            continue
        duration_ms = _number(row.get(SAMSUNG_FIELDS["workout_duration"]))
        duration = duration_ms / 60000 if duration_ms and duration_ms > 0 else _minutes(start, end)
        output.append({"start": start, "end": end, "duration_minutes": duration, "mean_hr": _number(row.get(SAMSUNG_FIELDS["workout_mean_hr"])), "max_hr": _number(row.get(SAMSUNG_FIELDS["workout_max_hr"])), "energy_kcal": _number(row.get(SAMSUNG_FIELDS["workout_calorie"])), "workout_type": row.get(SAMSUNG_FIELDS["workout_type"]), "workout_id": row.get(SAMSUNG_FIELDS["workout_id"]), "source_field": SAMSUNG_FIELDS["workout_start"]})
    return sorted(output, key=lambda item: item["start"])


def _overlap(left: Mapping[str, Any], start: datetime, end: datetime) -> bool:
    return left["start"] < end and start < left["end"]


def attach_apple_activity_signals(
    workout_rows: Iterable[Mapping[str, Any]], *, heart_rate_rows: Iterable[Mapping[str, Any]] = (),
    resting_heart_rate_rows: Iterable[Mapping[str, Any]] = (), physical_effort_rows: Iterable[Mapping[str, Any]] = (),
    recovery_rows: Iterable[Mapping[str, Any]] = (),
) -> list[dict[str, Any]]:
    """Apply temporal joins; missing joins stay missing."""
    workouts = normalize_apple_workout_rows(workout_rows)
    hr = _normalize_apple_quantity(heart_rate_rows, "HKQuantityTypeIdentifierHeartRate", APPLE_FIELDS["heart_rate"])
    rhr = _normalize_apple_quantity(resting_heart_rate_rows, "HKQuantityTypeIdentifierRestingHeartRate", APPLE_FIELDS["resting_heart_rate"])
    effort = _normalize_apple_quantity(physical_effort_rows, "HKQuantityTypeIdentifierPhysicalEffort", APPLE_FIELDS["physical_effort"])
    recovery = _normalize_apple_quantity(recovery_rows, "HKQuantityTypeIdentifierHeartRateRecoveryOneMinute", APPLE_FIELDS["heart_rate_recovery_1min"])
    output = []
    for workout in workouts:
        start, end = workout["start"], workout["end"]
        matched_hr = [row for row in hr if _overlap(row, start, end)]
        same_day_rhr = [row["value"] for row in rhr if row["start"].astimezone(start.tzinfo).date() == start.astimezone(start.tzinfo).date()]
        matched_effort = [row for row in effort if _overlap(row, start, end) and str(row.get("unit") or "").replace(" ", "") in {"kcal/hr·kg", "kcal/hr*kg", "kcal/hrkg"}]
        candidates = [row for row in recovery if 0 <= (row["start"] - end).total_seconds() <= 180]
        enriched = dict(workout)
        if matched_hr:
            enriched.update(mean_hr=median(row["value"] for row in matched_hr), max_hr=max(row["value"] for row in matched_hr))
        if same_day_rhr:
            enriched["resting_hr"] = median(same_day_rhr)
        if matched_effort:
            enriched["physical_effort_load_kcal_per_kg"] = sum(row["value"] * _minutes(max(row["start"], start), min(row["end"], end)) / 60 for row in matched_effort)
        if candidates:
            enriched["direct_recovery_delta_bpm"] = min(candidates, key=lambda row: (row["start"] - end).total_seconds())["value"]
        output.append(enriched)
    return output


def normalize_samsung_recovery_rows(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        chart = row.get("chart_data") or row.get("com.samsung.shealth.exercise.recovery_heart_rate.chart_data")
        if isinstance(chart, str):
            try:
                chart = json.loads(chart)
            except (TypeError, ValueError):
                chart = None
        if isinstance(chart, Mapping):
            chart = chart.get("chart_data")
        if not isinstance(chart, list):
            continue
        candidates = [point for point in chart if isinstance(point, Mapping) and _number(point.get("elapsed_time")) is not None and _number(point.get("heart_rate")) is not None and abs(_number(point["elapsed_time"]) - SAMSUNG_RECOVERY_TARGET_MS) <= SAMSUNG_RECOVERY_TOLERANCE_MS]
        if not candidates:
            continue
        point = min(candidates, key=lambda item: abs(_number(item["elapsed_time"]) - SAMSUNG_RECOVERY_TARGET_MS))
        output.append({"exercise_id": row.get("exercise_id") or row.get(SAMSUNG_FIELDS["recovery_exercise_id"]), "recovery_hr_1min": _number(point.get("heart_rate")), "recovery_elapsed_time_ms": _number(point.get("elapsed_time")), "source_field": SAMSUNG_FIELDS["recovery_hr"]})
    return output


def attach_samsung_recovery_signals(workout_rows: Iterable[Mapping[str, Any]], recovery_rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    workouts = normalize_samsung_workout_rows(workout_rows)
    recovery = {row.get("exercise_id"): row for row in normalize_samsung_recovery_rows(recovery_rows) if row.get("exercise_id")}
    output = []
    for workout in workouts:
        enriched = dict(workout)
        matched = recovery.get(workout.get("workout_id"))
        if matched:
            enriched["recovery_hr_1min"] = matched["recovery_hr_1min"]
            peak = workout.get("max_hr")
            if peak is not None:
                enriched["direct_recovery_delta_bpm"] = peak - matched["recovery_hr_1min"]
        output.append(enriched)
    return output


def derive_activity_load(sessions: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    rows = []
    for session in sessions:
        start, end = session.get("start"), session.get("end")
        if not _valid_interval(start, end):
            continue
        duration = _minutes(start, end)
        resting, mean_hr, max_hr = session.get("resting_hr"), session.get("mean_hr"), session.get("max_hr")
        hrr_fraction = None
        weighted = None
        if all(_number(value) is not None for value in (resting, mean_hr, max_hr)) and float(max_hr) > float(resting):
            hrr_fraction = max(0.0, min(1.0, (float(mean_hr) - float(resting)) / (float(max_hr) - float(resting))))
            weighted = duration * hrr_fraction
        recovery = session.get("direct_recovery_delta_bpm")
        if recovery is None and _number(session.get("peak_hr") or max_hr) is not None and _number(session.get("recovery_hr_1min")) is not None:
            recovery = float(session.get("peak_hr") or max_hr) - float(session["recovery_hr_1min"])
        rows.append({"duration_minutes": round(duration, 4), "hrr_fraction": None if hrr_fraction is None else round(hrr_fraction, 6), "hrr_weighted_load_minutes": None if weighted is None else round(weighted, 4), "recovery_delta_bpm": None if _number(recovery) is None else round(float(recovery), 4), "physical_effort_load_kcal_per_kg": session.get("physical_effort_load_kcal_per_kg"), "energy_kcal": session.get("energy_kcal")})
    if not rows:
        return {"status": "blocked", "reason": "no_valid_activity_session", "session_count": 0, "duration_minutes": None, "hrr_weighted_load_minutes": None, "recovery_delta_bpm": None, "energy_kcal": None, "sessions": []}
    weighted_values = [row["hrr_weighted_load_minutes"] for row in rows]
    recovery_values = [row["recovery_delta_bpm"] for row in rows if row["recovery_delta_bpm"] is not None]
    energy_values = [float(row["energy_kcal"]) for row in rows if _number(row["energy_kcal"]) is not None]
    effort_values = [float(row["physical_effort_load_kcal_per_kg"]) for row in rows if _number(row["physical_effort_load_kcal_per_kg"]) is not None]
    return {"status": "computed_hrr_weighted" if all(value is not None for value in weighted_values) else "computed_duration_only", "reason": None if all(value is not None for value in weighted_values) else "resting_or_max_heart_rate_parameter_missing", "session_count": len(rows), "duration_minutes": round(sum(row["duration_minutes"] for row in rows), 4), "hrr_weighted_load_minutes": round(sum(weighted_values), 4) if all(value is not None for value in weighted_values) else None, "recovery_delta_bpm": round(median(recovery_values), 4) if recovery_values else None, "physical_effort_load_kcal_per_kg": round(sum(effort_values), 6) if effort_values else None, "energy_kcal": round(sum(energy_values), 4) if energy_values else None, "sessions": rows}


def _merge_datetime_intervals(intervals: Iterable[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    ordered = sorted((start, end) for start, end in intervals if end > start)
    merged: list[list[datetime]] = []
    for start, end in ordered:
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return [(start, end) for start, end in merged]


def _subtract_datetime_intervals(
    coverage: Iterable[tuple[datetime, datetime]], movement: Iterable[tuple[datetime, datetime]]
) -> list[tuple[datetime, datetime]]:
    output = []
    movement = _merge_datetime_intervals(movement)
    for start, end in _merge_datetime_intervals(coverage):
        cursor = start
        for left, right in movement:
            if right <= cursor or left >= end:
                continue
            if left > cursor:
                output.append((cursor, min(left, end)))
            cursor = max(cursor, min(right, end))
            if cursor >= end:
                break
        if cursor < end:
            output.append((cursor, end))
    return output


def derive_movement_distribution_credit(
    timeline_records: Iterable[Mapping[str, Any]], *, partition_edges_minutes: tuple[int, ...] = (0, 180, 360, 540, 720, 900, 1080, 1260, 1440)
) -> dict[str, Any]:
    """Derive the I1/I2 movement distribution term from coverage-tagged rows."""
    intervals = defaultdict(list)
    for row in timeline_records:
        state = row.get("state")
        start, end = row.get("start"), row.get("end")
        if state not in {"observed", "movement", "missing", "nonwear"} or not _valid_interval(start, end):
            continue
        intervals[state].append((start, end))
    observed = _merge_datetime_intervals(intervals["observed"])
    uncertain = _merge_datetime_intervals(intervals["missing"] + intervals["nonwear"])
    movement = _merge_datetime_intervals(intervals["movement"])
    observed_minutes = sum(_minutes(start, end) for start, end in observed)
    if observed_minutes < 1440 or uncertain:
        return {"status": "blocked", "reason": "timeline_not_complete", "credit": None}
    if any(
        max(observed_start, uncertain_start) < min(observed_end, uncertain_end)
        for observed_start, observed_end in observed
        for uncertain_start, uncertain_end in uncertain
    ):
        return {"status": "blocked", "reason": "timeline_observation_conflict", "credit": None}
    if len(partition_edges_minutes) < 2 or partition_edges_minutes[0] != 0 or partition_edges_minutes[-1] != 1440 or any(left >= right for left, right in zip(partition_edges_minutes, partition_edges_minutes[1:])):
        raise ValueError("partition_edges_minutes")
    partition_durations = []
    for index, (left_edge, right_edge) in enumerate(zip(partition_edges_minutes, partition_edges_minutes[1:])):
        anchor = min((start for start, _ in intervals["observed"]), default=None)
        if anchor is None:
            return {"status": "blocked", "reason": "no_observed_timeline", "credit": None}
        start = anchor.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(minutes=left_edge)
        end = anchor.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(minutes=right_edge)
        partition_durations.append(sum(max(0.0, _minutes(max(start, move_start), min(end, move_end))) for move_start, move_end in movement if max(start, move_start) < min(end, move_end)))
    total = sum(partition_durations)
    active = sum(value > 0 for value in partition_durations)
    concentration = max(partition_durations) / total if total else None
    credit = 0.0 if total == 0 else active / len(partition_durations) * max(0.0, min(1.0, (1 - concentration) / 0.75))
    return {"status": "computed", "credit": round(credit, 9), "movement_minutes": round(total, 4), "active_partition_count": active, "partition_count": len(partition_durations), "activity_concentration": None if concentration is None else round(concentration, 9)}


def _action_credit_rows(rows: list[dict[str, Any]], set_complete: bool) -> float | list[float] | None:
    if not set_complete or not rows:
        return None
    known = []
    possible = []
    for row in rows:
        if row.get("eligibility") == "not_applicable":
            continue
        if row.get("outcome") == "completed":
            if row.get("measurement") == "structured_report":
                known.append(1.0)
            else:
                minutes = _number(row.get("action_duration"))
                known.append(max(0.0, min(1.0, minutes / 10.0)) if minutes is not None else None)
        elif row.get("outcome") == "not_completed":
            known.append(0.0)
        else:
            known.append(None)
        possible.append(row)
    if not possible:
        return None
    lower = sum(value for value in known if value is not None) / len(possible)
    upper = (sum(value for value in known if value is not None) + sum(value is None for value in known)) / len(possible)
    return round(lower, 9) if lower == upper else [round(lower, 9), round(upper, 9)]


def derive_action_opportunities(
    *, anchors: Iterable[Mapping[str, Any]], timeline_records: Iterable[Mapping[str, Any]], followup_minutes: float = 120.0, family: str, set_complete: bool
) -> dict[str, Any]:
    """Pair service-declared anchors with device movement; use one movement once."""
    if family not in {"post_anchor", "inactivity_break"} or followup_minutes <= 0:
        raise ValueError("action_configuration")
    movement = _merge_datetime_intervals((row["start"], row["end"]) for row in timeline_records if row.get("state") == "movement" and _valid_interval(row.get("start"), row.get("end")))
    observed = _merge_datetime_intervals((row["start"], row["end"]) for row in timeline_records if row.get("state") == "observed" and _valid_interval(row.get("start"), row.get("end")))
    uncertain = _merge_datetime_intervals((row["start"], row["end"]) for row in timeline_records if row.get("state") in {"missing", "nonwear"} and _valid_interval(row.get("start"), row.get("end")))
    used: set[int] = set()
    output = []
    for anchor_row in sorted(anchors, key=lambda row: row["anchor_time"]):
        anchor = anchor_row.get("anchor_time")
        if not isinstance(anchor, datetime):
            try:
                anchor = datetime.fromisoformat(str(anchor).replace("Z", "+00:00"))
            except ValueError:
                continue
        end = anchor + timedelta(minutes=followup_minutes)
        candidates = [index for index, (start, stop) in enumerate(movement) if index not in used and start < end and anchor < stop]
        selected = candidates[0] if candidates else None
        if selected is not None:
            used.add(selected)
        fully_observed = any(start <= anchor and stop >= end for start, stop in observed) and not any(start < end and anchor < stop for start, stop in uncertain)
        outcome = "completed" if selected is not None else "not_completed" if fully_observed else "unknown"
        duration = None if selected is None else max(0.0, _minutes(max(anchor, movement[selected][0]), min(end, movement[selected][1])))
        output.append({"family": family, "stratum": anchor_row.get("stratum", "unspecified"), "anchor_time": anchor.isoformat(), "eligibility": "eligible", "outcome": outcome, "measurement": "observed_duration", "action_duration": duration, "duration_unit": "minutes" if duration is not None else None, "followup_observed": selected is not None or fully_observed})
    return {"opportunities": output, "set_complete": set_complete, "credit": _action_credit_rows(output, set_complete)}


def derive_inactivity_break_opportunities(
    *, timeline_records: Iterable[Mapping[str, Any]], eligible_intervals: Iterable[Mapping[str, Any]], minimum_low_movement_minutes: float = 30.0, followup_minutes: float = 120.0, stratum: str = "day"
) -> dict[str, Any]:
    """Create break anchors at the threshold crossing of covered low movement."""
    eligible = []
    for row in eligible_intervals:
        if _valid_interval(row.get("start"), row.get("end")):
            eligible.append((row["start"], row["end"]))
    observed = [(row["start"], row["end"]) for row in timeline_records if row.get("state") == "observed" and _valid_interval(row.get("start"), row.get("end"))]
    movement = [(row["start"], row["end"]) for row in timeline_records if row.get("state") == "movement" and _valid_interval(row.get("start"), row.get("end"))]
    coverage = [(max(start, other_start), min(end, other_end)) for start, end in _merge_datetime_intervals(observed) for other_start, other_end in eligible if max(start, other_start) < min(end, other_end)]
    low = _subtract_datetime_intervals(coverage, movement)
    anchors = [{"anchor_time": start + timedelta(minutes=minimum_low_movement_minutes), "stratum": stratum} for start, end in low if end - start >= timedelta(minutes=minimum_low_movement_minutes)]
    complete = all(any(start <= left and right <= end for left, right in _merge_datetime_intervals(observed)) for start, end in eligible)
    return derive_action_opportunities(anchors=anchors, timeline_records=timeline_records, followup_minutes=followup_minutes, family="inactivity_break", set_complete=complete)


def normalize_apple_physiology_rows(rows: Iterable[Mapping[str, Any]], *, context: str) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        if row.get("type") == "HKQuantityTypeIdentifierHeartRateVariabilitySDNN":
            metric, unit, source = "sdnn", "ms", APPLE_FIELDS["hrv_sdnn"]
        elif row.get("type") == "HKQuantityTypeIdentifierRestingHeartRate":
            metric, unit, source = "rhr", "bpm", APPLE_FIELDS["resting_heart_rate"]
        else:
            continue
        start = _parse_apple_time(row.get("startDate")); end = _parse_apple_time(row.get("endDate")) or start
        value = _number(row.get("value"))
        if start is not None and end is not None and end >= start and value is not None:
            output.append({"lane_id": "apple_physio", "device": "apple", "metric": metric, "unit": unit, "value": value, "start": start, "end": end, "local_day": start.date().isoformat(), "context": context, "quality_status": row.get("quality_status", "unassessed"), "source_fields": [source]})
    return _dedupe_readings(output)


def normalize_samsung_physiology_rows(rows: Iterable[Mapping[str, Any]], *, context: str) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        start = _parse_samsung_time(row.get("start_time"), row.get("time_offset")); end = _parse_samsung_time(row.get("end_time"), row.get("time_offset"))
        if not _valid_interval(start, end):
            continue
        for metric, source in (("rmssd", SAMSUNG_FIELDS["hrv_rmssd"]), ("sdnn", SAMSUNG_FIELDS["hrv_sdnn"])):
            value = _number(row.get(metric))
            if value is not None:
                output.append({"lane_id": "samsung_physio", "device": "samsung", "metric": metric, "unit": "ms", "value": value, "start": start, "end": end, "local_day": start.astimezone(KST).date().isoformat(), "context": context, "quality_status": row.get("quality_status", "unassessed"), "source_fields": [source, SAMSUNG_FIELDS["hrv_start"], SAMSUNG_FIELDS["hrv_end"]]})
    return _dedupe_readings(output)


def normalize_samsung_hrv_rows(rows: Iterable[Mapping[str, Any]], *, context: str) -> list[dict[str, Any]]:
    """Public adapter name for Samsung HRV rows."""
    return normalize_samsung_physiology_rows(rows, context=context)


def _dedupe_readings(readings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)
    for reading in readings:
        grouped[(reading["lane_id"], reading["metric"], reading["start"], reading["end"], reading["context"])].append(reading)
    output = []
    for group in grouped.values():
        if len({row["value"] for row in group}) == 1:
            output.append(group[0])
    return sorted(output, key=lambda row: (row["local_day"], row["start"], row["metric"]))


def calculate_baseline_deviation(readings: Iterable[Mapping[str, Any]], *, current_day: str | None = None, min_baseline_days: int = 3, window_days: int = 28) -> dict[str, Any]:
    values = list(readings)
    if not values:
        return {"status": "blocked", "reason": "no_readings"}
    identities = {(row["lane_id"], row["device"], row["metric"], row["unit"], row["context"]) for row in values}
    if len(identities) != 1:
        return {"status": "blocked", "reason": "lane_metric_unit_or_context_mismatch"}
    lane_id, device, metric, unit, context = next(iter(identities))
    eligible = [row for row in values if row.get("quality_status") in {"observed", "observed_sufficient"}]
    by_day: dict[str, list[float]] = defaultdict(list)
    for row in eligible:
        by_day[row["local_day"]].append(float(row["value"]))
    latest = current_day or max(row["local_day"] for row in values)
    if latest not in by_day:
        return {"status": "blocked", "lane_id": lane_id, "device": device, "metric": metric, "unit": unit, "context": context, "current_day": latest, "reason": "recent_day_not_quality_eligible", "valid_baseline_days": 0}
    prior = sorted(day for day in by_day if day < latest)[-window_days:]
    if len(prior) < min_baseline_days:
        return {"status": "blocked", "lane_id": lane_id, "device": device, "metric": metric, "unit": unit, "context": context, "current_day": latest, "reason": "insufficient_same_lane_baseline_days", "valid_baseline_days": len(prior)}
    current = median(by_day[latest]); daily = [median(by_day[day]) for day in prior]; center = median(daily); mad = median(abs(value - center) for value in daily)
    deviation = current - center
    robust_z = None if mad == 0 else round(0.6745 * deviation / mad, 9)
    return {"status": "available", "lane_id": lane_id, "device": device, "metric": metric, "unit": unit, "context": context, "current_day": latest, "current_value": current, "baseline_value": center, "deviation": deviation, "direction": "higher" if deviation > 0 else "lower" if deviation < 0 else "unchanged", "valid_baseline_days": len(prior), "baseline_mad": mad, "robust_z": robust_z, "reason": None}


def reject_samsung_ordinary_hr_as_rhr() -> dict[str, Any]:
    return {"status": "blocked", "reason": "ordinary_heart_rate_not_resting_heart_rate", "source_field": SAMSUNG_FIELDS["ordinary_hr"]}
