# maiReport Operations v6.0

이 패키지는 v5.7 산식을 기준으로 디바이스 파생 신호를 선택적으로 반영하는
v6.0 계산 경계다. Python 3.11 이상, 표준 라이브러리만 사용하며 DB, 인증,
네트워크, 사용자 식별자를 포함하지 않는다.

## 실행

```sh
python3 maireport_ops.py fixtures/v6_full.json
python3 -m unittest -v test_delivery.py
```

`maireport_ops.py`는 정규화된 한 사람의 입력을 받는다. 공급자별 원본 필드
파싱과 전처리는 `device_preprocess.py`가 담당한다. 실제 앱에서는 각 기기의
원본 export/API 행을 이 파일의 함수에 넣고, 반환된 값만 산식 입력으로 보낸다.

## v6.0 산식

v5.7의 I1/I2/I3를 먼저 계산한다.

| 지표 | v6.0 반영 | 계산식 |
|---|---|---|
| I1 | 수면·활동 modifier, HRV/RHR 일치 패턴 cap | `clip(v5.7_I1 + sleep_modifier + activity_modifier, 0, 100)`; HRV 저하와 RHR 상승이 같은 기기·지표·상황 기준선에서 모두 `robust_z >= 1`/`<= -1`이면 최종 상한 70 |
| I2 | 변경 없음 | 걸음 수, 식후 행동, inactivity break, movement distribution만 행동 관측으로 사용. HRV/RHR·운동 강도는 행동 완료의 증거가 아님 |
| I3 | 기존 positive-context-conflict guard만 보강 | 같은 기기·상황의 HRV 저하+RHR 상승이 확인되면 `positive_context_conflict=true`; 행동 변화 자체를 HRV로 만들지 않음 |

수면 modifier는 최대 `+/-8`점이며 `0.6*efficiency_signal +
0.4*inverse_fragmentation_signal`이다. 활동 modifier는 최대 `+/-6`점이며
`0.6*recovery_delta_signal + 0.4*inverse_HRR_load_signal`이다. 각 signal은
같은 기기·같은 지표·같은 상황의 개인 기준선에 대해 `0.6745*(현재값-
기준선 중앙값)/MAD`를 계산하고 `[-1, 1]`로 제한한다. 기준선은 최소 3개의 유효
일별 값이 필요하다. MAD가 0이면 선언된 fallback scale을 쓰며, HRV/RHR cap은
robust z를 만들 수 없을 때 적용하지 않는다.

## 원본 필드에서 입력값 만들기

정확한 원본 항목명과 사용 여부는 `contracts/device-native-field-map-v6.0.json`,
정규화 입력 형태는 `contracts/formula-input-v6.0.schema.json`에 있다.

### 걸음 수와 활동 분포

1. Apple은 `HKQuantityTypeIdentifierStepCount.value/startDate/endDate`를
   같은 local day의 비중첩 interval로 합산한다.
2. Samsung은 `com.samsung.shealth.tracker.pedometer_day_summary.step_count`
   + `day_time`을 우선한다. 일일 요약이 없을 때만
   `com.samsung.health.step_count.start_time/end_time/count`를 합산한다.
3. 중복은 한 번만 세고, 겹치는 interval이나 자정 넘김 interval은 분할·비례
   배분하지 않고 해당 고해상도 파생값에서 제외한다. 일일 요약이 있으면 같은
   데이터를 interval과 다시 더하지 않는다.
4. 유효한 timestamped step interval에서 `steps > 0`이면 제공된 interval을
   `movement`로 본다. `steps = 0`이면 그 interval만 `observed`로 볼 수 있고
   활동으로 세지 않는다. interval 밖으로 시간을 확장하지 않으며, 이 행들만으로
   24시간 coverage를 만들지 않는다. `step_intervals_to_timeline_records`가 이
   변환을 수행한다.
5. `movement_distribution_credit`과 I1 rich 입력은 timestamped movement와
   별도의 `observed/missing/nonwear` coverage 행에서 만든다. 양의 걸음 기록 하나만
   가지고 24시간 관측 완료로 간주하지 않는다.
6. `inactivity_break_reactivation`과 `postmeal_activity_timing`은 coverage가
   확인된 movement timeline에서 만든다. `device_preprocess.py`의
   `derive_action_opportunities`를 사용하되, anchor는 서비스가 제공해야 한다.

### 수면

Apple은 `HKCategoryTypeIdentifierSleepAnalysis.value/startDate/endDate`의
값을 `in_bed`, `awake`, `light`, `deep`, `rem` 등으로 매핑한다. Samsung은
`com.samsung.health.sleep_stage.stage/start_time/end_time`의
`40001=awake`, `40002=light`, `40003=deep`, `40004=rem`을 사용한다.
`derive_sleep_detail`은 수면 창, asleep minutes, stage proportion, sleep
efficiency, transitions/hour를 만든다. `in_bed`는 envelope라 상태 stage와
겹칠 수 있지만, 두 개의 non-`in_bed` 상태가 겹치면 차단한다. Samsung의
`sleep_duration` 요약은 stage duration과 중복 합산하지 않는다.

### 운동·심박

Apple workout은 `Workout.startDate/endDate`와 `duration/durationUnit`으로
세션을 만들고, 같은 세션과 겹치는 `HeartRate.value`를 결합한다.
`RestingHeartRate.value`는 같은 local day의 중앙값만 RHR로 사용한다.
`HeartRateRecoveryOneMinute.value`는 운동 종료 후 180초 이내 가장 가까운
값을 사용한다. Samsung 운동은
`com.samsung.health.exercise.start_time/end_time/duration/mean_heart_rate/max_heart_rate`
를 사용하며 duration 단위는 milliseconds다. 회복은 recovery CSV의
`exercise_id`를 exercise CSV의 `datauuid`와 연결하고, 참조된 JSON
`chart_data[]`에서 `elapsed_time=60000ms +/- 2000ms`인 가장 가까운
`heart_rate`를 고른다.

HRR load는 `duration_minutes * clip((mean_HR-resting_HR)/(max_HR-resting_HR),0,1)`이다.
RHR 또는 max HR이 없거나 분모가 0 이하이면 HRR load는 `null`이고 duration-only
상태를 유지한다. 없는 값을 0이나 추정값으로 채우지 않는다.

### HRV/RHR 개인 기준선

- Apple: `HKQuantityTypeIdentifierHeartRateVariabilitySDNN.value`는 **SDNN**으로만 사용하고, `HKQuantityTypeIdentifierRestingHeartRate.value`는 별도 **RHR**로 사용한다. Apple SDNN을 RMSSD로 이름만 바꾸지 않는다.
- Samsung: `com.samsung.health.hrv.rmssd`와 `com.samsung.health.hrv.sdnn`은 각각 별도 metric lane이다. `start_time/end_time`을 보존한다.
- `com.samsung.health.hrv.binning_data`만 있는 행은 숫자 HRV 값이 아니다.
- `com.samsung.health.heart_rate.heart_rate`는 일반 심박수이므로 Samsung RHR로 사용하지 않는다.
- 기준선 key는 `device + metric + context`다. Apple SDNN, Samsung RMSSD,
  Samsung SDNN을 서로 합치지 않으며 sleep/awake/exercise context도 섞지 않는다.
- 품질이 `observed` 또는 `observed_sufficient`인 값만 기준선에 넣는다. 최근 값이
  품질 미달이면 과거 값으로 조용히 대체하지 않는다. 동일 구간의 값이 충돌하는
  중복은 차단한다.

## 디바이스로 얻을 수 없는 입력

다음은 디바이스 신호에서 추정하지 않고 서비스가 별도로 제공한다.

| 입력 | 공급원 | 이유 |
|---|---|---|
| `anchor_time`, `stratum` | 사용자가 기록한 식사/서비스 이벤트 | 걸음·심박만으로 식사 시각을 확정할 수 없음 |
| `eligible_intervals` | 서비스의 생활시간 정책 | 기기 신호가 행동 기회를 정의하지 않음 |
| `structured_report` 완료 | 서비스 질문/행동 보고 | 생리신호는 행동 완료가 아님 |
| `sleep_shortfall_minutes`의 기준 수면시간 | 제품 입력 정책 또는 사용자 설정 | 디바이스 수면시간과 목표 수면시간은 다른 값 |
| `target_channel_comparable` | 서비스의 동일 행동·동일 측정창 판정 | 서로 다른 채널의 변화는 I3 행동 변화로 비교하지 않음 |

`structured_report` 완료 행은 `measurement=structured_report`와
`outcome=completed`인 서비스 이벤트를 뜻한다. 질문 문구나 사용자 ID를 이
패키지에 넣지 않는다.

## 현재 v6.0에서 점수에 쓰지 않는 값

`Workout.totalEnergyBurned`, Samsung `calorie`, Apple
`PhysicalEffort`, Apple `ActiveEnergyBurned`는 원본 보존·감사·향후 분석을
위해 정규화할 수 있지만 v6.0 점수에는 직접 가중하지 않는다. HRV/RHR도 I1의
일치 패턴 cap과 I3 conflict guard에만 사용한다. 이 경계를 지켜야 에너지나
생리값을 행동 완료로 잘못 해석하지 않는다.

## 결측·운영 경계

결측, 잘못된 단위, 잘못된 시간창, 충돌 중복, 불충분한 개인 기준선은 `null` 또는
`blocked`로 남긴다. 0으로 대체하지 않는다. 이 패키지는 산식 전달물이며,
실제 서비스의 인증·사용자별 저장·DB schema·수집 주기·임상 타당성 검증은
범위에 포함하지 않는다.

제공 fixture는 실행 경계와 방향성 검증용이다. 실제 사용자 데이터에 대한
외부 타당성이나 계수 재보정의 증거로 사용하지 않는다.
