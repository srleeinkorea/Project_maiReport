import json
import sys
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path

from maireport_ops import score
from device_preprocess import (
    KST,
    attach_apple_activity_signals,
    attach_samsung_recovery_signals,
    calculate_baseline_deviation,
    derive_action_opportunities,
    derive_activity_load,
    derive_movement_distribution_credit,
    derive_sleep_detail,
    normalize_apple_physiology_rows,
    normalize_apple_sleep_rows,
    normalize_apple_step_rows,
    normalize_apple_physiology_rows,
    normalize_samsung_hrv_rows,
    normalize_samsung_sleep_stage_rows,
    normalize_samsung_workout_rows,
    reconcile_daily_steps,
    step_intervals_to_timeline_records,
)


class DeliveryTests(unittest.TestCase):
    def test_full_fixture_has_v6_modifier_and_physio_cap(self):
        payload = json.loads((Path(__file__).parent / "fixtures/v6_full.json").read_text())
        result = score(payload)["results"]
        self.assertEqual(result["i1"]["v6_0_result"]["status"], "candidate_v6_device_enriched_life_margin")
        self.assertTrue(result["i1"]["device_modifiers"]["physiology_cap_applied"])
        self.assertEqual(result["i2"]["v5_7_result"], result["i2"]["v6_0_result"])

    def test_no_device_keeps_base_i1(self):
        payload = {"formula_version": "v6.0", "inputs": {"i1": {"mode": "record_proxy", "daily_steps": 6000}, "i2": {"daily_steps": 6000, "post_anchor_action_credit": None, "inactivity_break_credit": None, "movement_distribution_credit": None}, "i3": {"action_connection_delta": None, "recorded_volume_direction": 0.25, "target_channel_comparable": False, "positive_context_conflict": None}}}
        result = score(payload)["results"]
        self.assertEqual(result["i1"]["v5_7_result"], result["i1"]["v6_0_result"])

    def test_provider_raw_fields_reach_normalized_constructs(self):
        apple_sleep = normalize_apple_sleep_rows([{"type": "HKCategoryTypeIdentifierSleepAnalysis", "value": "HKCategoryValueSleepAnalysisInBed", "startDate": "2026-09-10 23:00:00 +0900", "endDate": "2026-09-11 07:00:00 +0900"}, {"type": "HKCategoryTypeIdentifierSleepAnalysis", "value": "HKCategoryValueSleepAnalysisAsleepCore", "startDate": "2026-09-10 23:10:00 +0900", "endDate": "2026-09-11 06:50:00 +0900"}])
        samsung_sleep = normalize_samsung_sleep_stage_rows([{"stage": "40002", "start_time": "2026-09-10 23:00:00.000", "end_time": "2026-09-11 01:00:00.000", "time_offset": "UTC+0900"}])
        self.assertEqual(derive_sleep_detail(apple_sleep)["status"], "computed")
        self.assertEqual(derive_sleep_detail(samsung_sleep)["status"], "computed")
        steps = normalize_apple_step_rows([{"type": "HKQuantityTypeIdentifierStepCount", "value": "6000", "startDate": "2026-09-10 08:00:00 +0900", "endDate": "2026-09-10 09:00:00 +0900"}])
        daily = reconcile_daily_steps(apple_intervals=steps)
        self.assertEqual(daily[0]["steps"], 6000)

    def test_samsung_hrv_lanes_stay_separate(self):
        rows = normalize_samsung_hrv_rows([{"rmssd": "30", "sdnn": "42", "start_time": "2026-09-10 06:00:00.000", "end_time": "2026-09-10 06:05:00.000", "time_offset": "UTC+0900", "quality_status": "observed_sufficient"}], context="sleep")
        self.assertEqual({row["metric"] for row in rows}, {"rmssd", "sdnn"})
        self.assertEqual({row["unit"] for row in rows}, {"ms"})

    def test_activity_raw_signals_and_recovery_sidecar_join(self):
        apple_workout = [{"workoutActivityType": "walking", "startDate": "2026-09-10 09:00:00 +0900", "endDate": "2026-09-10 10:00:00 +0900", "duration": "60", "durationUnit": "min", "totalEnergyBurned": "300"}]
        apple = attach_apple_activity_signals(
            apple_workout,
            heart_rate_rows=[{"type": "HKQuantityTypeIdentifierHeartRate", "startDate": "2026-09-10 09:10:00 +0900", "endDate": "2026-09-10 09:20:00 +0900", "value": "130"}],
            resting_heart_rate_rows=[{"type": "HKQuantityTypeIdentifierRestingHeartRate", "startDate": "2026-09-10 07:00:00 +0900", "endDate": "2026-09-10 07:00:00 +0900", "value": "60"}],
            recovery_rows=[{"type": "HKQuantityTypeIdentifierHeartRateRecoveryOneMinute", "startDate": "2026-09-10 10:01:00 +0900", "endDate": "2026-09-10 10:01:00 +0900", "value": "55"}],
        )
        self.assertEqual(derive_activity_load(apple)["status"], "computed_hrr_weighted")
        samsung_workout = [{"com.samsung.health.exercise.start_time": "2026-09-10 09:00:00.000", "com.samsung.health.exercise.end_time": "2026-09-10 09:30:00.000", "com.samsung.health.exercise.duration": "1800000", "com.samsung.health.exercise.max_heart_rate": "170", "com.samsung.health.exercise.datauuid": "exercise-1", "time_offset": "UTC+0900"}]
        samsung_recovery = [{"com.samsung.shealth.exercise.recovery_heart_rate.exercise_id": "exercise-1", "chart_data": [{"elapsed_time": 59900, "heart_rate": 120}], "time_offset": "UTC+0900"}]
        attached = attach_samsung_recovery_signals(samsung_workout, samsung_recovery)
        self.assertEqual(derive_activity_load(attached)["recovery_delta_bpm"], 50)

    def test_apple_sdnn_baseline_is_same_metric_and_context(self):
        rows = normalize_apple_physiology_rows(
            [{"type": "HKQuantityTypeIdentifierHeartRateVariabilitySDNN", "value": value, "startDate": f"2026-09-{day:02d} 06:00:00 +0900", "endDate": f"2026-09-{day:02d} 06:05:00 +0900", "quality_status": "observed_sufficient"} for day, value in enumerate((40, 42, 41, 30), start=7)],
            context="sleep",
        )
        baseline = calculate_baseline_deviation(rows)
        self.assertEqual(baseline["metric"], "sdnn")
        self.assertEqual(baseline["context"], "sleep")
        self.assertEqual(baseline["status"], "available")

    def test_hrr_denominator_missing_is_not_zero(self):
        load = derive_activity_load([{"start": datetime(2026, 9, 10, 9, tzinfo=KST), "end": datetime(2026, 9, 10, 10, tzinfo=KST), "mean_hr": 120, "max_hr": 120}])
        self.assertEqual(load["status"], "computed_duration_only")
        self.assertIsNone(load["hrr_weighted_load_minutes"])

    def test_movement_and_action_require_coverage_and_service_anchor(self):
        day = datetime(2026, 9, 10, tzinfo=KST)
        timeline = [{"start": day, "end": day + timedelta(minutes=720), "state": "observed"}, {"start": day + timedelta(minutes=720), "end": day + timedelta(minutes=1440), "state": "observed"}, {"start": day + timedelta(minutes=100), "end": day + timedelta(minutes=110), "state": "movement"}]
        distribution = derive_movement_distribution_credit(timeline)
        self.assertEqual(distribution["status"], "computed")
        action = derive_action_opportunities(anchors=[{"anchor_time": day + timedelta(minutes=90), "stratum": "lunch"}], timeline_records=timeline, family="post_anchor", set_complete=True)
        self.assertEqual(action["opportunities"][0]["outcome"], "completed")
        self.assertGreater(action["credit"], 0)

    def test_timestamped_steps_become_movement_only_inside_their_interval(self):
        day = datetime(2026, 9, 10, tzinfo=KST)
        rows = step_intervals_to_timeline_records([
            {"start": day + timedelta(minutes=10), "end": day + timedelta(minutes=20), "steps": 100},
            {"start": day + timedelta(minutes=30), "end": day + timedelta(minutes=40), "steps": 0},
        ])
        self.assertEqual([row["state"] for row in rows], ["movement", "observed"])
        self.assertEqual(rows[0]["start"], day + timedelta(minutes=10))


if __name__ == "__main__":
    unittest.main()
