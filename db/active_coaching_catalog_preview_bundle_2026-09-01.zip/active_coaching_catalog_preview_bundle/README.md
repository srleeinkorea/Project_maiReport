# active_coaching_catalog preview bundle

작성일: 2026-09-01 KST  
기준 DB migration: `0474_pneumonia_dr_long_term_effects_provider_boundary`

이 bundle은 로컬 지식DB에 접근할 수 없는 개발팀이 운영용 `active_coaching_catalog`의 모양을 확인하기 위한 전달용 preview다. 개인 건강데이터 원본과 논문 원문은 포함하지 않았다.

## 1. 먼저 볼 파일

| 파일 | 용도 |
|---|---|
| `active_coaching_catalog_v0_snapshot.md` | 사람이 빠르게 읽는 전체 catalog 요약 |
| `active_coaching_catalog_v0_snapshot.csv` | spreadsheet에서 보는 active line catalog |
| `active_coaching_catalog_v0_snapshot.json` | 운영 API payload에 가까운 전체 예시 |
| `active_coaching_catalog_v0_column_lineage.csv` | catalog 필드가 지식DB 어느 컬럼에서 왔는지 보는 출처표 |
| `active_coaching_catalog_definition.md` | catalog 규칙과 컬럼 출처 설명 |
| `sample_user_daily_steps_input.json` | 일반인 최소 디바이스 데이터 입력 예시 |
| `sample_daily_steps_evaluation_output.json` | 위 입력을 평가했을 때 나오는 코칭 결과 예시 |
| `operational_preview_schema.sql` | 운영 DB에 둘 수 있는 최소 table 후보 |
| `active_coaching_catalog_preview.sqlite` | SQLite로 바로 열어볼 수 있는 preview DB |

## 2. 핵심 구조

```text
지식DB 내부 table
  coaching_line
  coaching_condition
  fact
  final_coaching_audience_contract
  coaching_line_claim
  behavior_signal_claim
        ↓
active_coaching_catalog snapshot
        ↓
운영 DB 저장
        ↓
사용자 normalized observation과 비교
        ↓
코칭 노출
```

운영 서버가 지식DB 내부 table을 직접 join하는 구조가 아니라, 지식DB에서 만든 catalog snapshot을 운영 DB에 저장하고 사용자 데이터와 비교하는 구조를 전제로 한다.

## 3. SQLite로 preview 보기

macOS 기본 `sqlite3`로 바로 확인할 수 있다.

```bash
sqlite3 active_coaching_catalog_preview.sqlite
```

대표 질의:

```sql
.tables

select line_id, headline, delivery_rule_status, trigger_types
from active_coaching_catalog
order by population_condition, line_id;

select *
from active_coaching_catalog
where line_id = 'general_daily_steps_below_7000_reconnect';

select catalog_field_group, source_columns
from active_coaching_catalog_column_lineage;
```

## 4. 현재 snapshot 상태

| 항목 | 값 |
|---|---:|
| active catalog row | 20 |
| `machine_evaluable` | 17 |
| `legacy_unexpressed_runtime_trigger` | 3 |

`legacy_unexpressed_runtime_trigger`는 active line이지만 자동 노출 조건이 아직 table로 충분히 표현되지 않은 row다. 운영 자동 노출에서는 보류하거나 trigger를 보강해야 한다.

## 5. 대표 예시

`general_daily_steps_below_7000_reconnect`는 일반인 하루 걸음수 코칭 예시다.

```text
Samsung Health StepDailyTrend source_type=-2
  → daily_step_count
  → fact_seq=190, [7000,) step_per_day
  → observed 5800 is below
  → 오늘 걸음 수가 목표보다 낮아요
```

이 line은 `fact_axis` trigger이고 필요한 normalized signal은 `daily_step_count`, 단위는 `step_per_day`다.

## 6. 포함하지 않은 것

| 제외 항목 | 이유 |
|---|---|
| 사용자 건강데이터 원본 | 개인정보 위험 |
| raw evidence body / reference paper 원문 | 운영 catalog 이해에는 과하고 용량/권리 이슈가 있음 |
| `.handoff/current.md` | 내부 작업 인계와 blind 금지 정보가 포함됨 |
| 전체 Postgres dump | 운영 preview에 불필요한 내부 table까지 노출됨 |

