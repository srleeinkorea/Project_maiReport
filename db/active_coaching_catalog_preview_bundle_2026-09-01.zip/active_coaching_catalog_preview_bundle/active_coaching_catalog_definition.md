# active_coaching_catalog 정의와 컬럼 출처

작성일: 2026-09-01 KST  
SQL preview: `docs/active_coaching_catalog_v0.sql`

이 문서는 개발팀과 함께 운영용 `active_coaching_catalog` 규칙을 정리하기 위한 자료다. 목적은 현재 지식DB의 여러 table에 나뉘어 있는 active coaching line 정보를 운영 서버가 읽기 쉬운 하나의 catalog payload로 합치는 것이다.

개발팀이 로컬 지식DB에 접근할 수 없는 경우에는 SQL이 아니라 아래 정적 snapshot 파일을 보면 된다.

| 파일 | 용도 |
|---|---|
| `docs/active_coaching_catalog_v0_snapshot.md` | 사람이 빠르게 읽는 전체 catalog 요약 |
| `docs/active_coaching_catalog_v0_snapshot.csv` | spreadsheet에서 보는 row 단위 catalog |
| `docs/active_coaching_catalog_v0_snapshot.json` | 운영 payload에 가까운 전체 catalog 예시 |
| `docs/active_coaching_catalog_v0_column_lineage.csv` | catalog 필드가 어느 지식DB 컬럼에서 왔는지 보는 출처표 |

## 1. 결론

운영 DB에는 지식DB 내부 table 전체를 복사하지 않고, 지식DB에서 만든 `active_coaching_catalog` snapshot을 배포하는 방식이 적절하다.

```text
지식DB 내부 table
  fact
  coaching_condition
  coaching_line
  final_coaching_audience_contract
  coaching_line_claim
  behavior_signal_claim
        ↓
지식DB에서 active_coaching_catalog 생성
        ↓
운영 DB에 catalog_version 단위로 저장
        ↓
운영 서버가 사용자 normalized observation과 비교
```

개발팀이 지식DB 구조를 이해할 수 있도록 catalog에는 두 종류의 정보가 같이 들어가야 한다.

| 정보 | 설명 |
|---|---|
| 운영 실행용 필드 | 운영 서버가 코칭 후보를 평가하고 메시지를 노출하는 데 필요한 값 |
| 컬럼 출처 정보 | 이 catalog 필드가 지식DB의 어떤 table/column에서 만들어졌는지 보여주는 lineage |

## 2. 현재 DB 기준 catalog 상태

현재 DB 기준으로 `active_coaching_catalog_v0` preview를 만들면 active line은 20개다.

| delivery rule status | 의미 | 현재 row 수 |
|---|---|---:|
| `machine_evaluable` | fact/event/sample/gate requirement 중 하나 이상이 table로 표현되어 운영 서버가 조건 평가를 할 수 있다. | 17 |
| `legacy_unexpressed_runtime_trigger` | active line이지만 현재 table에 자동 노출 trigger가 충분히 표현되어 있지 않다. 운영 자동 노출 catalog에서는 별도 보류 또는 수동 정책 매핑이 필요하다. | 3 |

`legacy_unexpressed_runtime_trigger`로 잡히는 line은 아래 3개다.

| line_id | condition | headline |
|---|---|---|
| `dm_break_up_prolonged_sitting` | `diabetes` | 한참 앉아 있게 되는 날엔 30분마다 잠깐 걸어보세요 |
| `pneumonia_recovery_lower_intensity` | `pneumonia` | 회복 중엔 강도를 평소보다 낮춰요 |
| `pneumonia_rise_slowly_after_lying` | `pneumonia` | 한참 누워 있다 일어날 땐 천천히 일어나 보세요 |

따라서 catalog 생성 규칙에는 `delivery_rule_status`가 반드시 필요하다. active line이라고 해서 모두 자동 노출 가능한 것은 아니다.

## 3. catalog 필드 정의

| catalog 필드 | 운영에서 쓰는 의미 | source table.column |
|---|---|---|
| `catalog_schema_version` | catalog payload 형식 버전 | export 생성 시 부여 |
| `catalog_version` | 운영 배포 snapshot 버전 | export/publish 단계에서 부여 |
| `line_id` | 코칭 메시지 고유 id | `coaching_line.line_id` |
| `headline` | 사용자에게 보이는 제목 | `coaching_line.headline` |
| `detail` | 사용자에게 보이는 본문 | `coaching_line.detail` |
| `population_condition` | 지식DB의 condition scope | `coaching_line.population_condition` |
| `delivery_rule_status` | 자동 평가 가능 여부 | requirement table 존재 여부에서 파생 |
| `trigger_types` | 이 line이 어떤 종류의 조건으로 열리는지 | `coaching_condition`, `coaching_line_event_requirement`, `coaching_line_sample_requirement`, `coaching_line_gate_requirement`에서 파생 |
| `fact_conditions` | 정량 fact 축 조건 목록 | `coaching_condition` + `fact` |
| `required_measurement_target_keys` | 운영이 준비해야 하는 normalized signal key | `fact.measurement_target_key` |
| `required_units` | 사용자 observation 단위 | `fact.unit` |
| `event_requirements` | 필요한 event 종류 | `coaching_line_event_requirement.event_kind` |
| `sample_requirements` | 필요한 sample 관찰 조건 | `coaching_line_sample_requirement.requirement_kind` |
| `gate_contract_ids` | 필요한 product/runtime gate | `coaching_line_gate_requirement.gate_contract_id` |
| `audience_scope_kind` | 일반 웰니스인지 condition-specific인지 | `final_coaching_audience_contract.audience_scope_kind` |
| `target_user_classification` | 운영이 어떤 사용자로 분류해야 하는지 | `final_coaching_audience_contract.target_user_classification` |
| `classifier_owner` | 사용자 분류 책임 주체 | `final_coaching_audience_contract.classifier_owner` |
| `kb_role` | 지식DB가 이 line에서 맡는 역할 | `final_coaching_audience_contract.kb_role` |
| `required_runtime_classifications` | 운영이 확인해야 하는 runtime 분류 | `final_coaching_audience_contract.required_runtime_classifications` |
| `required_behavior_or_context_signals` | 운영/평가 결과로 필요한 상태 신호 | `final_coaching_audience_contract.required_behavior_or_context_signals` |
| `exclusion_runtime_classifications` | 제외해야 하는 운영 분류 | `final_coaching_audience_contract.exclusion_runtime_classifications` |
| `forbidden_kb_roles` | 이 line으로 하면 안 되는 역할 | `final_coaching_audience_contract.forbidden_kb_roles` |
| `claim_ids` | 메시지에 연결된 검증 claim id | `coaching_line_claim.claim_id` |
| `all_claims_satisfied` | 모든 연결 claim이 satisfied인지 | `behavior_signal_claim.status`에서 파생 |
| `claims` | claim id, status, statement 묶음 | `coaching_line_claim` + `behavior_signal_claim` |
| `source_column_map` | catalog 각 필드의 지식DB 컬럼 출처 | SQL preview에서 명시적으로 생성 |

## 4. trigger type 규칙

`active_coaching_catalog`는 line이 열리는 방식을 한 가지로 가정하면 안 된다. 현재 DB에는 네 종류의 trigger가 있다.

| trigger type | source table | 운영 평가 방식 |
|---|---|---|
| `fact_axis` | `coaching_condition` + `fact` | 사용자 normalized observation을 fact 기준값과 비교해 `below/within/above`를 만든다. |
| `event_requirement` | `coaching_line_event_requirement` | 식사, 좌식 bout 같은 event가 있어야 line 후보가 된다. |
| `sample_requirement` | `coaching_line_sample_requirement` | 특정 sample 관찰 조건이 있어야 line 후보가 된다. |
| `gate_requirement` | `coaching_line_gate_requirement` | 운영/product gate contract가 충족되어야 line 후보가 된다. |

어느 trigger table에도 걸리지 않는 active line은 `legacy_unexpressed_runtime_trigger`로 표시한다. 운영 자동 노출에서 이 line들을 그대로 열면 안 된다.

## 5. 일반 하루 걸음수 코칭 catalog row 예시

`general_daily_steps_below_7000_reconnect`는 현재 가장 설명하기 좋은 active catalog 예시다.

| catalog 필드 | 값 |
|---|---|
| `line_id` | `general_daily_steps_below_7000_reconnect` |
| `headline` | 오늘 걸음 수가 목표보다 낮아요 |
| `population_condition` | `general` |
| `delivery_rule_status` | `machine_evaluable` |
| `trigger_types` | `fact_axis` |
| `required_measurement_target_keys` | `daily_step_count` |
| `required_units` | `step_per_day` |
| `fact_conditions[0].fact_seq` | `190` |
| `fact_conditions[0].quantity` | `[7000,)` |
| `fact_conditions[0].required_position` | `below` |
| `fact_conditions[0].range_type` | `minimum_threshold` |
| `fact_conditions[0].population_age` | `[18,65)` |
| `required_runtime_classifications` | `general_wellness_context`, `daily_steps_signal_available` |
| `required_behavior_or_context_signals` | `daily_steps_below_reference_axis` |
| `claim_ids` | `daily_steps_around_7000_status_target_adults`, `total_activity_associates_with_clamp_insulin_sensitivity` |

운영 서버는 이 row를 보고 다음처럼 판단할 수 있다.

```text
필요한 사용자 데이터:
  normalized_signal_key = daily_step_count
  unit = step_per_day
  source_policy = reconciled
  age = [18,65) 안

판정:
  observed daily_steps < 7000 이면 position=below

결과:
  line_id = general_daily_steps_below_7000_reconnect 노출 가능
```

## 6. catalog 생성 SQL preview

개발팀 검토용 SQL은 아래 파일에 별도로 두었다.

```text
docs/active_coaching_catalog_v0.sql
```

이 SQL은 현재 DB에서 임시 view로 생성해 검증했다. 실제 schema migration으로 승격하려면 현재 미적용 migration 뒤의 번호로 옮기고, 아래 조건을 테스트로 고정해야 한다.

| 테스트해야 할 것 | 이유 |
|---|---|
| row 수가 `coaching_line` 수와 같다 | active line 누락 방지 |
| `general_daily_steps_below_7000_reconnect`가 `fact_axis`로 나온다 | 하루 걸음수 대표 예시 고정 |
| `fact_seq=190`의 threshold/unit/measurement target이 포함된다 | 운영 평가에 필요한 기준 누락 방지 |
| `legacy_unexpressed_runtime_trigger` line이 구분된다 | 자동 노출하면 안 되는 line을 막기 위함 |
| `source_column_map`에 핵심 필드 출처가 들어간다 | 개발팀이 catalog를 역추적할 수 있게 하기 위함 |

## 7. 운영 DB 업데이트 방식

운영 DB에 저장할 때는 catalog를 현재값으로 덮어쓰기보다 versioned snapshot으로 저장하는 편이 낫다.

```text
active_coaching_catalog_snapshot
  catalog_version
  catalog_schema_version
  published_at
  line_id
  payload_json
  source_column_map_json
```

운영 delivery log에는 최소한 아래 값을 남긴다.

```text
coaching_delivery_log
  user_id
  catalog_version
  line_id
  fact_seq
  observed_value
  threshold
  position
  delivered_at
  suppressed_reason
```

이렇게 해야 지식DB가 나중에 업데이트되어도, 과거 특정 사용자에게 왜 어떤 코칭이 나갔는지 재현할 수 있다.

## 8. 개발팀과 합의할 지점

개발팀과 정해야 할 것은 지식DB 내부 table 구조가 아니라 운영 catalog의 계약이다.

| 합의 항목 | 결정해야 하는 내용 |
|---|---|
| catalog 배포 단위 | 전체 snapshot인지, condition별 snapshot인지 |
| catalog version 규칙 | migration version 기반인지, 별도 publish version인지 |
| 운영 DB 저장 방식 | row-per-line인지, JSON payload snapshot인지 |
| trigger 지원 범위 | v0에서 `fact_axis`만 먼저 열지, event/sample/gate까지 같이 열지 |
| legacy line 처리 | 자동 노출 제외, 수동 정책 매핑, 또는 trigger 보강 후 배포 중 선택 |
| traceability 노출 수준 | 운영 DB에 claim id만 저장할지, source/package/span ref까지 저장할지 |

현재 일반 하루 걸음수 코칭만 운영 v0로 먼저 연다면 `fact_axis` trigger부터 지원해도 된다. 다만 전체 active line을 한 번에 운영하려면 event, sample, gate trigger까지 함께 설계해야 한다.
