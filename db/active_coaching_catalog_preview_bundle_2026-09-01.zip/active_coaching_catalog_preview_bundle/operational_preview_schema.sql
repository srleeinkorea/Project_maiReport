-- 운영 DB preview schema 후보
--
-- 실제 운영 스키마 확정안이 아니라, active_coaching_catalog를 운영 DB에서 어떻게 저장하고
-- 사용자 데이터와 비교할지 논의하기 위한 최소 구조다.

create table active_coaching_catalog_snapshot (
    catalog_version text not null,
    catalog_schema_version text not null,
    published_at text not null,
    line_id text not null,
    payload_json text not null,
    source_column_map_json text not null,
    primary key (catalog_version, line_id)
);

create table user_runtime_context (
    user_id text not null,
    runtime_classification text not null,
    classification_source text,
    valid_from text not null,
    valid_to text,
    primary key (user_id, runtime_classification, valid_from)
);

create table user_device_signal_capability (
    user_id text not null,
    platform text not null,
    normalized_signal_key text not null,
    status text not null,
    source_policy text,
    last_observed_at text,
    primary key (user_id, platform, normalized_signal_key)
);

create table normalized_daily_step_observation (
    user_id text not null,
    observed_date text not null,
    daily_steps real not null,
    unit text not null,
    source text not null,
    source_policy text not null,
    primary key (user_id, observed_date, source)
);

create table coaching_delivery_log (
    delivery_id text primary key,
    user_id text not null,
    catalog_version text not null,
    line_id text not null,
    fact_seq integer,
    observed_value real,
    threshold real,
    position text,
    delivered_at text not null,
    suppressed_reason text
);
