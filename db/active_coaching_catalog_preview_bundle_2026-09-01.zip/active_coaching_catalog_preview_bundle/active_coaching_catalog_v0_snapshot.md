# active_coaching_catalog v0 정적 snapshot

작성일: 2026-09-01 KST

이 파일은 로컬 지식DB에 접근할 수 없는 개발팀 검토를 위해 현재 DB에서 `active_coaching_catalog_v0` 결과를 정적으로 뽑은 것이다.

## 1. Export 정보

| 항목 | 값 |
|---|---|
| source SQL | `docs/active_coaching_catalog_v0.sql` |
| latest applied migration at export | `0474_pneumonia_dr_long_term_effects_provider_boundary` |
| row count | `20` |
| JSON snapshot | `docs/active_coaching_catalog_v0_snapshot.json` |
| CSV snapshot | `docs/active_coaching_catalog_v0_snapshot.csv` |

## 2. 상태 요약

| delivery_rule_status | row 수 |
|---|---:|
| `legacy_unexpressed_runtime_trigger` | 3 |
| `machine_evaluable` | 17 |

## 3. 전체 catalog 요약

| condition | line_id | headline | status | trigger | required signal/unit | event/sample/gate |
|---|---|---|---|---|---|---|
| `diabetes` | `dm_below_guideline_glycemia` | 조금 더 움직이면 혈당 조절에 도움이 돼요 | `machine_evaluable` | `fact_axis` | `moderate_intensity_aerobic_exercise`, `moderate_to_vigorous_intensity_aerobic_activity`<br/>`minute_per_week` | - |
| `diabetes` | `dm_break_up_prolonged_sitting` | 한참 앉아 있게 되는 날엔 30분마다 잠깐 걸어보세요 | `legacy_unexpressed_runtime_trigger` | `legacy_unexpressed_runtime_trigger` | - | - |
| `diabetes` | `dm_daily_short_of_target_move_after_meals` | 오늘은 목표만큼 못 움직였어요 — 식사 후에 움직여 볼까요? | `machine_evaluable` | `fact_axis`, `event_requirement` | `aerobic_activity`<br/>`minute_per_day` | event=`meal_event` |
| `diabetes` | `dm_few_active_days_try_short_bouts` | 운동한 날이 권고보다 적어요 — 1분씩 아주 힘들게, 짧게라도 해볼까요? | `machine_evaluable` | `fact_axis` | `moderate_to_vigorous_intensity_aerobic_activity`<br/>`day_per_week` | - |
| `diabetes` | `dm_gap_between_sessions_too_long` | 운동을 몰아서 하기보다 사이를 좁혀볼까요? | `machine_evaluable` | `fact_axis` | `days_elapsed_between_exercise_sessions`<br/>`day_interval` | - |
| `diabetes` | `dm_plan_postmeal_activity` | 식사 뒤에 움직일 시간을 미리 잡아볼까요? | `machine_evaluable` | `event_requirement` | - | event=`meal_event` |
| `diabetes` | `dm_shift_walking_to_after_meals` | 같은 30분이라면 식후에 나눠 걸어보세요 | `machine_evaluable` | `fact_axis`, `event_requirement` | `aerobic_activity`, `moderate_intensity_aerobic_exercise`, `moderate_to_vigorous_intensity_aerobic_activity`<br/>`minute_per_day`, `minute_per_week` | event=`meal_event` |
| `diabetes` | `dm_start_soon_after_meal` | 식사 후에 움직일 거라면 되도록 일찍 시작해 보세요 | `machine_evaluable` | `event_requirement` | - | event=`meal_event` |
| `diabetes` | `dm_walk_after_meal_instead_of_sitting` | 식사 뒤에는 앉아만 있기보다 걸어보세요 | `machine_evaluable` | `event_requirement` | - | event=`meal_event` |
| `general` | `aerobic_below_guideline_start` | 유산소 운동을 조금 늘려볼까요? | `machine_evaluable` | `fact_axis` | `moderate_intensity_activity`, `moderate_intensity_aerobic_physical_activity`, `moderate_intensity_physical_activity`, `vigorous_intensity_activity`, `vigorous_intensity_aerobic_physical_activity`, `vigorous_intensity_physical_activity`<br/>`minute_per_week` | - |
| `general` | `aerobic_volume_is_not_the_lever` | 오늘은 운동 시간을 더 늘리지 않아도 돼요 | `machine_evaluable` | `fact_axis` | `moderate_intensity_activity`, `moderate_intensity_aerobic_activity`, `moderate_intensity_aerobic_physical_activity`, `moderate_intensity_physical_activity`, `vigorous_intensity_activity`, `vigorous_intensity_aerobic_physical_activity`, `vigorous_intensity_physical_activity`<br/>`minute_per_week` | - |
| `general` | `general_daily_steps_below_7000_reconnect` | 오늘 걸음 수가 목표보다 낮아요 | `machine_evaluable` | `fact_axis` | `daily_step_count`<br/>`step_per_day` | - |
| `general` | `general_inactivity_gap_move_prompt` | 한동안 움직임이 없었다면 잠깐 일어나 볼까요? | `machine_evaluable` | `gate_requirement` | - | gate=`gate_explicit_sedentary_bout_break` |
| `general` | `general_regular_short_sleep_duration` | 최근 수면 시간이 자주 7시간 아래로 내려가요 | `machine_evaluable` | `fact_axis` | `good_quality_sleep`<br/>`hour_per_day` | - |
| `general` | `general_short_ambulatory_mvpa_proxy` | 짧게 빠르게 움직인 시간이 있었어요 | `machine_evaluable` | `sample_requirement` | - | sample=`short_ambulatory_mvpa_proxy` |
| `general` | `general_sleep_timing_regular_context` | 수면 시간이 괜찮아도 몸은 시차를 느낄 수 있어요 | `machine_evaluable` | `gate_requirement` | - | gate=`gate_sleep_timing_history` |
| `general` | `general_walk_after_meal_instead_of_sitting` | 식사 뒤에는 앉아만 있기보다 잠깐 걸어보세요 | `machine_evaluable` | `event_requirement` | - | event=`meal_event` |
| `general` | `general_weight_compensation_expectation_context` | 운동을 해도 체중이 바로 따라오지 않을 수 있어요 | `machine_evaluable` | `gate_requirement` | - | gate=`gate_weight_goal_compensation_context` |
| `pneumonia` | `pneumonia_recovery_lower_intensity` | 회복 중엔 강도를 평소보다 낮춰요 | `legacy_unexpressed_runtime_trigger` | `legacy_unexpressed_runtime_trigger` | - | - |
| `pneumonia` | `pneumonia_rise_slowly_after_lying` | 한참 누워 있다 일어날 땐 천천히 일어나 보세요 | `legacy_unexpressed_runtime_trigger` | `legacy_unexpressed_runtime_trigger` | - | - |

## 4. 대표 row: 하루 걸음수 코칭

| 필드 | 값 |
|---|---|
| `line_id` | general_daily_steps_below_7000_reconnect |
| `headline` | 오늘 걸음 수가 목표보다 낮아요 |
| `detail` | 오늘 7,000보에 아직 못 닿았다면 긴 운동으로 한 번에 채우려 하지 말고, 편한 시간에 짧은 산책이나 이동을 한 번 더해보세요. 이 기준은 일일 걸음수 상태를 보는 참고점입니다. |
| `population_condition` | general |
| `delivery_rule_status` | machine_evaluable |
| `trigger_types` | `fact_axis` |
| `required_measurement_target_keys` | `daily_step_count` |
| `required_units` | `step_per_day` |
| `required_runtime_classifications` | `general_wellness_context`, `daily_steps_signal_available` |
| `required_behavior_or_context_signals` | `daily_steps_below_reference_axis` |
| `forbidden_kb_roles` | `runtime_user_classification`, `infer_user_diagnosis`, `verify_ai_report_status`, `create_treatment_plan`, `create_clearance`, `create_prescription`, `create_risk_score` |
| `claim_ids` | `daily_steps_around_7000_status_target_adults`, `total_activity_associates_with_clamp_insulin_sensitivity` |

### fact_conditions

| 필드 | 값 |
|---|---|
| `unit` | `step_per_day` |
| `fact_seq` | `190` |
| `quantity` | `[7000,)` |
| `authority` | `Australian Government Department of Health, Disability and Ageing` |
| `range_type` | `minimum_threshold` |
| `doc_version` | `2025 report` |
| `semantic_kind` | `count_steps` |
| `population_age` | `[18,65)` |
| `population_region` | `AU` |
| `required_position` | `below` |
| `measurement_target_key` | `daily_step_count` |
| `value_provenance_grade` | `companion_statement` |

## 5. 컬럼 출처

전체 lineage는 JSON snapshot의 각 row에 들어 있는 `source_column_map`에 포함되어 있다. 사람이 빠르게 볼 수 있는 요약은 `docs/active_coaching_catalog_정의와_컬럼출처.md`의 catalog 필드 정의 표를 본다.
