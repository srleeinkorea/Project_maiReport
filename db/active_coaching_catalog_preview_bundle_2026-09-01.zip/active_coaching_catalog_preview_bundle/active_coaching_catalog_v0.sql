-- active_coaching_catalog v0 preview
--
-- 목적:
-- - 운영 DB가 지식DB 내부 table을 직접 join하지 않도록, active coaching line의 실행 조건을
--   한 payload로 합친다.
-- - 이 파일은 개발팀 합의용 preview다. DB 정본으로 승격할 때는 미적용 migration 뒤의 번호로
--   `지식DB/db/migrations/*.sql`에 넣는다.

create or replace view mai_active_coaching_catalog_v0 as
with fact_conditions as (
    select
        cc.line_id,
        jsonb_agg(
            jsonb_build_object(
                'fact_seq', cc.fact_seq,
                'required_position', cc.position,
                'measurement_target_key', f.measurement_target_key,
                'unit', f.unit,
                'quantity', f.quantity::text,
                'range_type', f.range_type,
                'semantic_kind', f.semantic_kind,
                'population_age', f.population_age::text,
                'population_region', f.population_region,
                'authority', f.authority,
                'doc_version', f.doc_version,
                'value_provenance_grade', f.value_provenance_grade
            )
            order by cc.fact_seq, cc.position
        ) as fact_conditions,
        array_agg(distinct f.measurement_target_key)
            filter (where f.measurement_target_key is not null) as required_measurement_target_keys,
        array_agg(distinct f.unit)
            filter (where f.unit is not null) as required_units
    from coaching_condition cc
    join fact f on f.fact_seq = cc.fact_seq
    group by cc.line_id
),
event_requirements as (
    select
        line_id,
        array_agg(event_kind order by event_kind) as event_requirements
    from coaching_line_event_requirement
    group by line_id
),
sample_requirements as (
    select
        line_id,
        array_agg(requirement_kind order by requirement_kind) as sample_requirements
    from coaching_line_sample_requirement
    group by line_id
),
gate_requirements as (
    select
        line_id,
        array_agg(gate_contract_id order by gate_contract_id) as gate_contract_ids
    from coaching_line_gate_requirement
    group by line_id
),
claim_links as (
    select
        clc.line_id,
        array_agg(clc.claim_id order by clc.claim_id) as claim_ids,
        bool_and(bsc.status = 'satisfied') as all_claims_satisfied,
        jsonb_agg(
            jsonb_build_object(
                'claim_id', clc.claim_id,
                'claim_status', bsc.status,
                'statement', bsc.statement
            )
            order by clc.claim_id
        ) as claims
    from coaching_line_claim clc
    join behavior_signal_claim bsc on bsc.claim_id = clc.claim_id
    group by clc.line_id
)
select
    'active_coaching_catalog_v0'::text as catalog_schema_version,
    cl.line_id,
    cl.headline,
    cl.detail,
    cl.population_condition,
    case
        when fc.line_id is null
         and er.line_id is null
         and sr.line_id is null
         and gr.line_id is null
        then 'legacy_unexpressed_runtime_trigger'
        else 'machine_evaluable'
    end as delivery_rule_status,
    case
        when fc.line_id is null
         and er.line_id is null
         and sr.line_id is null
         and gr.line_id is null
        then array['legacy_unexpressed_runtime_trigger']::text[]
        else array_remove(array[
            case when fc.line_id is not null then 'fact_axis' end,
            case when er.line_id is not null then 'event_requirement' end,
            case when sr.line_id is not null then 'sample_requirement' end,
            case when gr.line_id is not null then 'gate_requirement' end
        ]::text[], null)
    end as trigger_types,
    coalesce(fc.fact_conditions, '[]'::jsonb) as fact_conditions,
    coalesce(fc.required_measurement_target_keys, array[]::text[]) as required_measurement_target_keys,
    coalesce(fc.required_units, array[]::text[]) as required_units,
    coalesce(er.event_requirements, array[]::text[]) as event_requirements,
    coalesce(sr.sample_requirements, array[]::text[]) as sample_requirements,
    coalesce(gr.gate_contract_ids, array[]::text[]) as gate_contract_ids,
    fac.audience_scope_kind,
    fac.target_user_classification,
    fac.classifier_owner,
    fac.kb_role,
    coalesce(fac.required_runtime_classifications, array[]::text[]) as required_runtime_classifications,
    coalesce(fac.required_behavior_or_context_signals, array[]::text[]) as required_behavior_or_context_signals,
    coalesce(fac.exclusion_runtime_classifications, array[]::text[]) as exclusion_runtime_classifications,
    coalesce(fac.forbidden_kb_roles, array[]::text[]) as forbidden_kb_roles,
    coalesce(claims.claim_ids, array[]::text[]) as claim_ids,
    coalesce(claims.all_claims_satisfied, false) as all_claims_satisfied,
    coalesce(claims.claims, '[]'::jsonb) as claims,
    jsonb_build_object(
        'line_id', jsonb_build_array('coaching_line.line_id'),
        'headline', jsonb_build_array('coaching_line.headline'),
        'detail', jsonb_build_array('coaching_line.detail'),
        'population_condition', jsonb_build_array('coaching_line.population_condition'),
        'fact_conditions', jsonb_build_array(
            'coaching_condition.fact_seq',
            'coaching_condition.position',
            'fact.measurement_target_key',
            'fact.quantity',
            'fact.unit',
            'fact.range_type',
            'fact.semantic_kind',
            'fact.population_age',
            'fact.population_region',
            'fact.authority',
            'fact.doc_version',
            'fact.value_provenance_grade'
        ),
        'event_requirements', jsonb_build_array('coaching_line_event_requirement.event_kind'),
        'sample_requirements', jsonb_build_array('coaching_line_sample_requirement.requirement_kind'),
        'gate_contract_ids', jsonb_build_array('coaching_line_gate_requirement.gate_contract_id'),
        'audience_contract', jsonb_build_array(
            'final_coaching_audience_contract.audience_scope_kind',
            'final_coaching_audience_contract.target_user_classification',
            'final_coaching_audience_contract.classifier_owner',
            'final_coaching_audience_contract.kb_role',
            'final_coaching_audience_contract.required_runtime_classifications',
            'final_coaching_audience_contract.required_behavior_or_context_signals',
            'final_coaching_audience_contract.exclusion_runtime_classifications',
            'final_coaching_audience_contract.forbidden_kb_roles'
        ),
        'claims', jsonb_build_array(
            'coaching_line_claim.claim_id',
            'behavior_signal_claim.status',
            'behavior_signal_claim.statement'
        )
    ) as source_column_map
from coaching_line cl
left join fact_conditions fc on fc.line_id = cl.line_id
left join event_requirements er on er.line_id = cl.line_id
left join sample_requirements sr on sr.line_id = cl.line_id
left join gate_requirements gr on gr.line_id = cl.line_id
left join final_coaching_audience_contract fac on fac.line_id = cl.line_id
left join claim_links claims on claims.line_id = cl.line_id;
