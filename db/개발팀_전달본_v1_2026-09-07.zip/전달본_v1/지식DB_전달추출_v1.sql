-- maiReport KDB candidate contract v1, 2026-09-07.
-- 서버 KDB에서 실행하는 순수 SELECT. DDL/DML/임시 객체/수동 map_* 없음.
-- 한 행의 bundle JSONB를 반환한다. manifest.validation_errors가 비어 있어야 한다.
-- 후보 계약이며 사용자 발송 승인이 아니다. 사용법/필드 의미는 같은 폴더 README.md.
WITH RECURSIVE
quality_exclusions AS (
    SELECT line_id, to_jsonb(q) AS detail
    FROM public.mai_kdb_server_migration_quality_gate_matrix q
    WHERE include_in_product_usable_seed IS NOT TRUE
),
lines AS (
    SELECT l.* FROM public.coaching_line l
    WHERE NOT EXISTS (SELECT 1 FROM quality_exclusions q WHERE q.line_id=l.line_id)
),
-- 대안 fact까지 보존한다. 연결되지 않은 대안을 0분/미달로 간주하지 않는다.
fact_ids(fact_seq) AS (
    SELECT cc.fact_seq FROM public.coaching_condition cc JOIN lines l USING(line_id)
    UNION
    SELECT peer.fact_seq FROM fact_ids i
    JOIN public.fact_alternative a ON a.fact_seq=i.fact_seq
    JOIN public.fact_alternative peer USING(group_id)
),
facts AS (
    SELECT f.* FROM public.fact_effective f JOIN fact_ids i USING(fact_seq)
),
sample_sources AS (
    SELECT DISTINCT s.requirement_kind, s.note
    FROM public.coaching_line_sample_requirement s JOIN lines l USING(line_id)
),
-- 현재 유일한 sample requirement의 서술 계약을 명시적으로 구조화한다.
-- note가 바뀌면 이전 해석을 적용하지 않는다. 새 kind도 validation error로 남긴다.
sample_contract AS (
    SELECT s.*, 'sample:'||requirement_kind AS metric_key,
        requirement_kind='short_ambulatory_mvpa_proxy' AND note =
        'timestamped StepCount/MET sample이 필요하다. 1분 이상 10분 미만인 단일 샘플에서 cadence >=100 steps/min 또는 MET >=3이면 관찰로 본다. daily total steps만으로는 세우지 않고, VILPA/MV-ILPA 라벨과 샘플 gap merge는 쓰지 않는다.'
        AS recognized,
        1::numeric AS min_bout_minutes, 10::numeric AS max_bout_minutes
    FROM sample_sources s
),
fact_signals AS (
    SELECT 'fact:'||f.fact_seq AS metric_key,
        u.intensity_definition_id AS signal_key, u.unit AS signal_unit,
        lower(u.quantity) AS signal_min, upper(u.quantity) AS signal_max,
        lower_inc(u.quantity) AS min_inclusive, upper_inc(u.quantity) AS max_inclusive,
        u.quantity::text AS source_range,
        CASE u.unit WHEN 'percent_hrmax'
             THEN ARRAY['measurement:heart_rate','profile:age']
             ELSE ARRAY['measurement:'||u.unit] END AS required_input_keys,
        'approved_definition'::text AS source_kind,
        jsonb_build_object('recommendation_package',f.package_id,
            'measurement_target_key',f.measurement_target_key,
            'definition_id',d.definition_id,'package_id',d.package_id,'span_id',d.span_id,
            'note',d.note) AS source_ref,
        NULL::integer AS selection_priority
    FROM facts f
    JOIN public.measurement_target_intensity_usable u
      ON u.recommendation_package=f.package_id
     AND u.measurement_target_key=f.measurement_target_key
    JOIN public.measurement_definition d ON d.definition_id=u.intensity_definition_id
),
direct_signals AS (
    SELECT 'fact:'||f.fact_seq AS metric_key,
        CASE f.unit WHEN 'hour_per_day' THEN 'sleep_session_hours'
                    WHEN 'step_per_day' THEN 'reconciled_daily_steps' END AS signal_key,
        f.unit AS signal_unit, NULL::numeric AS signal_min, NULL::numeric AS signal_max,
        false AS min_inclusive, false AS max_inclusive, NULL::text AS source_range,
        CASE f.unit WHEN 'hour_per_day' THEN ARRAY['event:sleep_session']
                    WHEN 'step_per_day' THEN ARRAY['measurement:daily_step_total'] END AS required_input_keys,
        'direct_observation'::text AS source_kind,
        jsonb_build_object('fact_seq',f.fact_seq,'package_id',f.package_id,
            'adapter_contract',CASE f.unit WHEN 'hour_per_day' THEN 'dated_night_sleep_hours'
                ELSE 'dated_source_reconciled_step_total' END) AS source_ref,
        NULL::integer AS selection_priority
    FROM facts f
    WHERE (f.unit='hour_per_day' AND f.measurement_target_key='good_quality_sleep')
       OR (f.unit='step_per_day' AND f.measurement_target_key='daily_step_count')
),
sample_signals AS (
    SELECT s.metric_key, v.signal_key, v.signal_unit, v.signal_min,
        NULL::numeric AS signal_max, true AS min_inclusive, false AS max_inclusive,
        NULL::text AS source_range, ARRAY['measurement:'||v.signal_unit] AS required_input_keys,
        'sample_requirement'::text AS source_kind,
        jsonb_build_object('requirement_kind',s.requirement_kind,'note',s.note,
            'structured_interpretation_version','short_ambulatory_mvpa_proxy/v1') AS source_ref,
        NULL::integer AS selection_priority
    FROM sample_contract s
    CROSS JOIN (VALUES ('cadence','steps_per_min',100::numeric),('met','MET',3::numeric))
       v(signal_key,signal_unit,signal_min)
    WHERE s.recognized
),
coaching_metric_signal AS (
    SELECT * FROM fact_signals UNION ALL SELECT * FROM direct_signals
    UNION ALL SELECT * FROM sample_signals
),
coaching_metric AS (
    SELECT 'fact:'||f.fact_seq AS metric_key, 'fact_axis'::text AS metric_kind,
        f.measurement_target_key AS native_target, f.unit,
        f.fact_seq AS source_fact_seq, f.package_id AS recommendation_package,
        jsonb_build_object('min',lower(f.quantity),'max',upper(f.quantity),
            'min_inclusive',lower_inc(f.quantity),'max_inclusive',upper_inc(f.quantity),
            'range',f.quantity::text,'range_type',f.range_type) AS reference_quantity,
        jsonb_build_object('condition',f.population_condition,'region',f.population_region,
            'age_min',lower(f.population_age),'age_max',upper(f.population_age),
            'age_min_inclusive',lower_inc(f.population_age),
            'age_max_inclusive',upper_inc(f.population_age),'age_range',f.population_age::text) AS population,
        coalesce((SELECT jsonb_agg(to_jsonb(o)-'fact_seq' ORDER BY o.rule_kind)
            FROM public.coaching_axis_observation_rule o WHERE o.fact_seq=f.fact_seq),'[]'::jsonb) AS observation_rules,
        coalesce((SELECT jsonb_agg(jsonb_build_object('input_key','event:'||e.event_kind,'note',e.note)
            ORDER BY e.event_kind) FROM public.coaching_axis_event_requirement e
            WHERE e.fact_seq=f.fact_seq),'[]'::jsonb) AS axis_event_requirements,
        CASE WHEN m.bout_fact_seq IS NOT NULL THEN
            jsonb_build_object('bout_fact_seq',m.bout_fact_seq,'min',lower(b.quantity),
                'max',upper(b.quantity),'min_inclusive',lower_inc(b.quantity),
                'max_inclusive',upper_inc(b.quantity),'unit',b.unit,
                'source','measurement_target_activity',
                'application_scope','target_relation_not_automatic_total_volume_filter')
            ELSE NULL END AS target_bout_reference,
        NULL::jsonb AS sample_contract,
        coalesce((SELECT jsonb_agg(jsonb_build_object('group_id',a.group_id,
            'source_package',a.package_id,'source_span',a.span_id,
            'member_metric_keys',(SELECT jsonb_agg('fact:'||peer.fact_seq ORDER BY peer.fact_seq)
                FROM public.fact_alternative peer WHERE peer.group_id=a.group_id)) ORDER BY a.group_id)
            FROM public.fact_alternative a WHERE a.fact_seq=f.fact_seq),'[]'::jsonb) AS alternative_groups,
        CASE WHEN EXISTS(SELECT 1 FROM coaching_metric_signal s WHERE s.metric_key='fact:'||f.fact_seq)
            THEN 'measurement_path_available' ELSE 'no_usable_measurement_path' END AS measurement_state,
        'operating_adapter_required'::text AS calculation_state,
        jsonb_build_object('fact_seq',f.fact_seq,'package_id',f.package_id,
            'mention_range',f.mention_range::text,'authority',f.authority,'doc_version',f.doc_version,
            'provenance_grade',f.value_provenance_grade,'transformation_rule',f.transformation_rule) AS source_ref
    FROM facts f
    LEFT JOIN public.measurement_target_activity m USING(measurement_target_key)
    LEFT JOIN public.fact_effective b ON b.fact_seq=m.bout_fact_seq
    UNION ALL
    SELECT s.metric_key, 'sample_observation', s.requirement_kind, 'count',
        NULL::bigint,NULL::text,NULL::jsonb,NULL::jsonb,'[]'::jsonb,'[]'::jsonb,NULL::jsonb,
        jsonb_build_object('recognized',s.recognized,'interpretation_version','short_ambulatory_mvpa_proxy/v1',
            'min_bout_minutes',s.min_bout_minutes,'max_bout_minutes',s.max_bout_minutes,
            'min_inclusive',true,'max_inclusive',false,'single_sample_only',true,
            'merge_samples',false,'daily_total_steps_allowed',false,'note',s.note),
        '[]'::jsonb,
        CASE WHEN s.recognized THEN 'measurement_path_available' ELSE 'no_usable_measurement_path' END,
        'operating_adapter_required', jsonb_build_object('requirement_kind',s.requirement_kind,'note',s.note)
    FROM sample_contract s
),
coaching_message AS (
    SELECT l.line_id AS message_id,l.headline AS title,l.detail AS body,l.population_condition,
        NULL::text AS topic,
        coalesce((SELECT jsonb_agg(to_jsonb(a)-'created_at' ORDER BY a.audience_contract_id)
            FROM public.final_coaching_audience_contract a WHERE a.line_id=l.line_id),'[]'::jsonb) AS audience_contracts,
        coalesce((SELECT jsonb_agg(jsonb_build_object('claim_id',lc.claim_id,'status',c.status,
            'statement',c.statement,'source_role','line_support') ORDER BY lc.claim_id)
            FROM public.coaching_line_claim lc JOIN public.behavior_signal_claim c USING(claim_id)
            WHERE lc.line_id=l.line_id),'[]'::jsonb) AS support_claims,
        coalesce((SELECT jsonb_agg(jsonb_build_object('claim_id',lc.claim_id,'status',c.status,
            'use_role',lc.use_role,'note',lc.note,'source_proposal_id',lc.source_proposal_id,
            'statement',c.statement) ORDER BY lc.claim_id)
            FROM public.coaching_line_context_claim lc JOIN public.behavior_signal_claim c USING(claim_id)
            WHERE lc.line_id=l.line_id),'[]'::jsonb) AS context_claims,
        coalesce((SELECT jsonb_agg(to_jsonb(t)-'created_at' ORDER BY t.trace_id)
            FROM public.coaching_line_guideline_principle_criteria_trace t
            WHERE t.line_id=l.line_id),'[]'::jsonb) AS criteria_traces,
        coalesce((SELECT jsonb_agg(jsonb_build_object('gate_contract_id',r.gate_contract_id,
            'line_requirement_note',r.note,'contract',to_jsonb(g)-'created_at') ORDER BY r.gate_contract_id)
            FROM public.coaching_line_gate_requirement r JOIN public.coaching_gate_contract g USING(gate_contract_id)
            WHERE r.line_id=l.line_id),'[]'::jsonb) AS gate_contracts,
        coalesce((SELECT jsonb_agg(jsonb_build_object('input_key','event:'||e.event_kind,'note',e.note)
            ORDER BY e.event_kind) FROM public.coaching_line_event_requirement e
            WHERE e.line_id=l.line_id),'[]'::jsonb) AS event_requirements,
        coalesce((SELECT jsonb_agg(jsonb_build_object('input_key','sample:'||s.requirement_kind,'note',s.note)
            ORDER BY s.requirement_kind) FROM public.coaching_line_sample_requirement s
            WHERE s.line_id=l.line_id),'[]'::jsonb) AS sample_requirements,
        'requires_operating_evaluation'::text AS candidate_state,
        jsonb_build_object('line_id',l.line_id,'known_product_exclusion',false) AS source_ref
    FROM lines l
),
rule_source AS (
    SELECT 'fact:'||cc.fact_seq||':'||cc.position||':'||cc.line_id AS rule_id,
        cc.line_id AS message_id,'metric_range'::text AS trigger_type,
        'fact:'||cc.fact_seq AS metric_key,cc.position AS source_position,
        CASE cc.position WHEN 'below' THEN NULL WHEN 'within' THEN lower(f.quantity)
                         WHEN 'above' THEN upper(f.quantity) END AS value_min,
        CASE cc.position WHEN 'below' THEN lower(f.quantity) WHEN 'within' THEN upper(f.quantity)
                         WHEN 'above' THEN NULL END AS value_max,
        CASE cc.position WHEN 'within' THEN lower_inc(f.quantity)
                         WHEN 'above' THEN NOT upper_inc(f.quantity) ELSE false END AS min_inclusive,
        CASE cc.position WHEN 'within' THEN upper_inc(f.quantity)
                         WHEN 'below' THEN NOT lower_inc(f.quantity) ELSE false END AS max_inclusive,
        jsonb_build_object('fact_seq',cc.fact_seq,'position',cc.position,'line_id',cc.line_id) AS source_ref
    FROM public.coaching_condition cc JOIN lines l USING(line_id) JOIN facts f USING(fact_seq)
    UNION ALL
    SELECT 'sample:'||s.requirement_kind||':'||s.line_id,s.line_id,'sample_observed',
        'sample:'||s.requirement_kind,NULL::text,1::numeric,NULL::numeric,true,false,
        jsonb_build_object('line_id',s.line_id,'requirement_kind',s.requirement_kind)
    FROM public.coaching_line_sample_requirement s JOIN lines l USING(line_id)
    UNION ALL
    SELECT 'context:'||l.line_id,l.line_id,'context_contract',NULL::text,NULL::text,
        NULL::numeric,NULL::numeric,false,false,jsonb_build_object('line_id',l.line_id)
    FROM lines l
    WHERE NOT EXISTS(SELECT 1 FROM public.coaching_condition c WHERE c.line_id=l.line_id)
      AND NOT EXISTS(SELECT 1 FROM public.coaching_line_sample_requirement s WHERE s.line_id=l.line_id)
),
coaching_rule AS (
    SELECT r.*,
        coalesce((SELECT jsonb_agg(k ORDER BY k) FROM (
            SELECT x->>'input_key' k FROM jsonb_array_elements(m.event_requirements) x
            UNION SELECT x->>'input_key' FROM jsonb_array_elements(m.sample_requirements) x
            UNION SELECT x->>'input_key' FROM jsonb_array_elements(coalesce(mt.axis_event_requirements,'[]'::jsonb)) x
        ) inputs),'[]'::jsonb) AS all_input_keys,
        CASE WHEN mt.measurement_state='no_usable_measurement_path'
             THEN 'blocked_no_usable_measurement_path' ELSE 'requires_operating_evaluation' END AS candidate_state,
        NULL::text AS rule_group,NULL::integer AS priority
    FROM rule_source r JOIN coaching_message m USING(message_id)
    LEFT JOIN coaching_metric mt USING(metric_key)
),
input_keys AS (
    SELECT DISTINCT jsonb_array_elements_text(r.all_input_keys) AS input_key FROM coaching_rule r
    UNION SELECT DISTINCT unnest(s.required_input_keys) FROM coaching_metric_signal s
    UNION SELECT 'profile:age' FROM facts WHERE NOT lower_inf(population_age) OR NOT upper_inf(population_age)
),
coaching_input AS (
    SELECT input_key,split_part(input_key,':',1) AS input_kind,
        substr(input_key,strpos(input_key,':')+1) AS native_key,
        NULL::text AS question_text_ko,NULL::integer AS freshness_hours,
        NULL::boolean AS available_now,
        'operating_system'::text AS adapter_owner
    FROM input_keys
),
validation_errors AS (
    SELECT 'no_exportable_messages'::text AS code,'coaching_message'::text AS object_id
    WHERE NOT EXISTS(SELECT 1 FROM lines)
    UNION ALL
    SELECT 'missing_effective_fact',i.fact_seq::text
    FROM fact_ids i WHERE NOT EXISTS(SELECT 1 FROM facts f WHERE f.fact_seq=i.fact_seq)
    UNION ALL
    SELECT 'missing_audience_contract',m.message_id FROM coaching_message m WHERE m.audience_contracts='[]'::jsonb
    UNION ALL
    SELECT 'missing_support_claim',m.message_id FROM coaching_message m WHERE m.support_claims='[]'::jsonb
    UNION ALL
    SELECT 'unsatisfied_support_claim',m.message_id FROM coaching_message m,
        jsonb_array_elements(m.support_claims) c WHERE c->>'status' IS DISTINCT FROM 'satisfied'
    UNION ALL
    SELECT 'unsupported_sample_contract',s.requirement_kind FROM sample_contract s WHERE s.recognized IS NOT TRUE
    UNION ALL
    SELECT 'missing_bout_fact',f.fact_seq::text FROM facts f
    JOIN public.measurement_target_activity a USING(measurement_target_key)
    WHERE a.bout_fact_seq IS NOT NULL AND NOT EXISTS(SELECT 1 FROM public.fact_effective b WHERE b.fact_seq=a.bout_fact_seq)
    UNION ALL
    SELECT 'message_without_rule',m.message_id FROM coaching_message m
    WHERE NOT EXISTS(SELECT 1 FROM coaching_rule r WHERE r.message_id=m.message_id)
    UNION ALL
    SELECT 'metric_rule_without_bounds',r.rule_id FROM coaching_rule r
    WHERE r.trigger_type IN ('metric_range','sample_observed') AND r.value_min IS NULL AND r.value_max IS NULL
    UNION ALL
    SELECT 'duplicate_metric_key',metric_key FROM coaching_metric GROUP BY metric_key HAVING count(*)<>1
    UNION ALL
    SELECT 'duplicate_signal_key',metric_key||':'||signal_key FROM coaching_metric_signal GROUP BY metric_key,signal_key HAVING count(*)<>1
),
tables AS (
    SELECT jsonb_build_object(
        'coaching_input',coalesce((SELECT jsonb_agg(to_jsonb(t) ORDER BY input_key) FROM coaching_input t),'[]'::jsonb),
        'coaching_metric',coalesce((SELECT jsonb_agg(to_jsonb(t) ORDER BY metric_key) FROM coaching_metric t),'[]'::jsonb),
        'coaching_metric_signal',coalesce((SELECT jsonb_agg(to_jsonb(t) ORDER BY metric_key,signal_key) FROM coaching_metric_signal t),'[]'::jsonb),
        'coaching_message',coalesce((SELECT jsonb_agg(to_jsonb(t) ORDER BY message_id) FROM coaching_message t),'[]'::jsonb),
        'coaching_rule',coalesce((SELECT jsonb_agg(to_jsonb(t) ORDER BY rule_id) FROM coaching_rule t),'[]'::jsonb)
    ) AS payload
),
source_manifest AS (
    SELECT jsonb_build_object('source_database',current_database(),
        'source_migration', (SELECT max(version) FROM public.schema_migration),
        'migration_set_md5',(SELECT md5(string_agg(version,E'\n' ORDER BY version)) FROM public.schema_migration),
        'source_line_count',(SELECT count(*) FROM public.coaching_line),
        'excluded_messages',coalesce((SELECT jsonb_agg(detail ORDER BY line_id) FROM quality_exclusions),'[]'::jsonb)
    ) AS data
)
SELECT jsonb_build_object(
    'manifest', s.data || jsonb_build_object(
        'contract_version','mai_coaching_candidate/v1',
        'generated_at',statement_timestamp(),
        'source_fingerprint',md5((s.data||t.payload)::text),
        'artifact_kind','candidate_contract_not_runtime_release',
        'validation_errors',coalesce((SELECT jsonb_agg(to_jsonb(e) ORDER BY code,object_id) FROM validation_errors e),'[]'::jsonb),
        'table_counts',jsonb_build_object('coaching_input',(SELECT count(*) FROM coaching_input),
            'coaching_metric',(SELECT count(*) FROM coaching_metric),
            'coaching_metric_signal',(SELECT count(*) FROM coaching_metric_signal),
            'coaching_message',(SELECT count(*) FROM coaching_message),
            'coaching_rule',(SELECT count(*) FROM coaching_rule))
    ), 'tables',CASE WHEN EXISTS(SELECT 1 FROM validation_errors) THEN NULL ELSE t.payload END
) AS bundle
FROM tables t CROSS JOIN source_manifest s;
