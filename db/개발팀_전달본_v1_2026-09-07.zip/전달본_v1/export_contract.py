"""Read the canonical server and validate/export the v1 candidate contract.

Usage: python3 export_contract.py --check
       python3 export_contract.py --output candidate_contract.json
No database writes. Output files are created exclusively, never overwritten.
"""
import argparse
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SQL_PATH = HERE / '지식DB_전달추출_v1.sql'


def connect_server():
    if (ROOT / '지식DB/db/migrate.py').exists():
        sys.path.insert(0, str(ROOT / '지식DB'))
        from db.migrate import connect
        conn = connect()
    else:
        import psycopg2
        required = ('PGHOST', 'PGPORT', 'PGDATABASE', 'PGUSER')
        if any(not os.environ.get(k) for k in required):
            raise RuntimeError('PGHOST/PGPORT/PGDATABASE/PGUSER를 서버 KDB로 설정하세요.')
        conn = psycopg2.connect('')
    try:
        # In the repository, independently compare the configured server target.
        server_env = ROOT / '지식DB/db/.env.server'
        if server_env.exists():
            env = dict(line.strip().split('=', 1) for line in server_env.read_text().splitlines()
                       if line.strip() and not line.strip().startswith('#') and '=' in line)
            dsn = conn.get_dsn_parameters()
            pairs = [('host', 'SERVER_PGHOST'), ('port', 'SERVER_PGPORT'),
                     ('dbname', 'SERVER_PGDATABASE'), ('user', 'SERVER_PGUSER')]
            if any(str(dsn[k]) != env.get(v, '').strip() for k, v in pairs):
                raise RuntimeError('기본 접속과 서버 정본 설정이 다릅니다. 접속값은 출력하지 않습니다.')
        conn.set_session(readonly=True, isolation_level='REPEATABLE READ')
        with conn.cursor() as cur:
            cur.execute("SET LOCAL statement_timeout = '60s'")
            cur.execute("SELECT current_database(), current_setting('transaction_read_only')")
            dbname, readonly = cur.fetchone()
            if dbname != 'health_knowledge' or readonly != 'on':
                raise RuntimeError('health_knowledge 서버 KDB의 읽기 전용 연결이 필요합니다.')
        return conn
    except Exception:
        conn.close()
        raise


def fetch_bundle(conn):
    with conn.cursor() as cur:
        cur.execute(SQL_PATH.read_text())
        return cur.fetchone()[0]


def validate_bundle(bundle):
    """Validate the export shape. This never approves runtime use."""
    errors = list(bundle['manifest']['validation_errors'])
    tables = bundle['tables']
    if tables is None:
        return errors or [{'code': 'missing_payload', 'object_id': 'tables'}]
    expected_keys = {
        'coaching_input': ('input_key',), 'coaching_metric': ('metric_key',),
        'coaching_metric_signal': ('metric_key', 'signal_key'),
        'coaching_message': ('message_id',), 'coaching_rule': ('rule_id',),
    }
    indexes = {}
    for name, keys in expected_keys.items():
        rows = tables[name]
        if bundle['manifest']['table_counts'][name] != len(rows):
            errors.append({'code': 'count_mismatch', 'object_id': name})
        index = {tuple(row[k] for k in keys): row for row in rows}
        if len(index) != len(rows):
            errors.append({'code': 'duplicate_key', 'object_id': name})
        indexes[name] = index
    inputs = indexes['coaching_input']
    metrics = indexes['coaching_metric']
    messages = indexes['coaching_message']
    excluded = {r['line_id'] for r in bundle['manifest']['excluded_messages']}
    if len(messages) + len(excluded) != bundle['manifest']['source_line_count']:
        errors.append({'code': 'source_line_coverage_mismatch', 'object_id': 'coaching_message'})
    for row in tables['coaching_message']:
        mid = row['message_id']
        if mid in excluded:
            errors.append({'code': 'excluded_message_exported', 'object_id': mid})
        if not row['audience_contracts'] or not row['support_claims']:
            errors.append({'code': 'missing_message_contract', 'object_id': mid})
        if row['candidate_state'] != 'requires_operating_evaluation':
            errors.append({'code': 'unexpected_runtime_authority', 'object_id': mid})
    for row in tables['coaching_rule']:
        rid = row['rule_id']
        if (row['message_id'],) not in messages:
            errors.append({'code': 'missing_message_fk', 'object_id': rid})
        if row['metric_key'] is not None and (row['metric_key'],) not in metrics:
            errors.append({'code': 'missing_metric_fk', 'object_id': rid})
        for key in row['all_input_keys']:
            if (key,) not in inputs:
                errors.append({'code': 'missing_input_fk', 'object_id': key})
        if row['trigger_type'] != 'context_contract' and row['value_min'] is None and row['value_max'] is None:
            errors.append({'code': 'missing_rule_bounds', 'object_id': rid})
    for row in tables['coaching_metric_signal']:
        if (row['metric_key'],) not in metrics:
            errors.append({'code': 'missing_signal_metric_fk', 'object_id': row['metric_key']})
        for key in row['required_input_keys']:
            if (key,) not in inputs:
                errors.append({'code': 'missing_signal_input_fk', 'object_id': key})
    for row in tables['coaching_metric']:
        for group in row['alternative_groups']:
            for key in group['member_metric_keys']:
                if (key,) not in metrics:
                    errors.append({'code': 'missing_alternative_metric', 'object_id': key})
    return errors


def build_insert_script(conn, bundle):
    """Generate operations-only SQL; do not execute it on this connection."""
    from psycopg2 import sql
    from psycopg2.extras import Json
    errors = validate_bundle(bundle)
    if errors:
        raise ValueError('검증 오류가 있어 적재 SQL을 생성하지 않습니다.')
    manifest = bundle['manifest']
    release_id = manifest['source_fingerprint']
    script = [
        '-- Operations DB only. Candidate contract, not runtime activation.',
        'BEGIN;',
        "DO $$ BEGIN IF current_database()='health_knowledge' THEN RAISE EXCEPTION "
        "'Do not load an operations contract into the canonical KDB'; END IF; END $$;",
    ]
    release = {'release_id': release_id, 'contract_version': manifest['contract_version'],
               'generated_at': manifest['generated_at'], 'source_migration': manifest['source_migration'],
               'manifest': manifest}
    with conn.cursor() as cur:
        def append_insert(table_name, row):
            values = [Json(v, dumps=lambda x: json.dumps(x, ensure_ascii=False))
                      if isinstance(v, dict) or isinstance(v, list) and k != 'required_input_keys'
                      else v for k, v in row.items()]
            statement = sql.SQL('INSERT INTO {}.{} ({}) VALUES ({});').format(
                sql.Identifier('maireport_kdb_v1'), sql.Identifier(table_name),
                sql.SQL(',').join(map(sql.Identifier, row)),
                sql.SQL(',').join(sql.Placeholder() for _ in row),
            )
            script.append(cur.mogrify(statement, values).decode('utf-8'))
        append_insert('coaching_contract_release', release)
        for name in ('coaching_input', 'coaching_metric', 'coaching_metric_signal',
                     'coaching_message', 'coaching_rule'):
            for row in bundle['tables'][name]:
                append_insert(name, {'release_id': release_id, **row})
    script.append('COMMIT;')
    return '\n'.join(script)+'\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='검증 요약만 출력')
    parser.add_argument('--output', type=Path, help='새 JSON 파일 경로; 기존 파일 덮어쓰기 없음')
    parser.add_argument('--sql-output', type=Path, help='운영 DB용 INSERT 파일 생성만 수행; 실행하지 않음')
    args = parser.parse_args()
    conn = connect_server()
    try:
        bundle = fetch_bundle(conn)
        errors = validate_bundle(bundle)
        insert_script = build_insert_script(conn, bundle) if args.sql_output and not errors else None
    finally:
        conn.rollback()
        conn.close()
    summary = {
        'contract_version': bundle['manifest']['contract_version'],
        'source_migration': bundle['manifest']['source_migration'],
        'table_counts': bundle['manifest']['table_counts'],
        'excluded_messages': [r['line_id'] for r in bundle['manifest']['excluded_messages']],
        'blocked_metrics': [r['metric_key'] for r in (bundle['tables'] or {}).get('coaching_metric', [])
                            if r['measurement_state'] == 'no_usable_measurement_path'],
        'validation_errors': errors,
        'runtime_release_approved': False,
    }
    if errors:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 1
    if args.output:
        with args.output.open('x', encoding='utf-8') as out:
            json.dump(bundle, out, ensure_ascii=False, indent=2)
            out.write('\n')
    if args.sql_output:
        with args.sql_output.open('x', encoding='utf-8') as out:
            out.write(insert_script)
    if args.check or args.output or args.sql_output:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    else:
        print(json.dumps(bundle, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
