-- psycopg 파라미터: bundle=json.dumps(추출본), runtime=json.dumps(운영 평가 결과).
-- 사용자 맥락/측정값을 평가하는 엔진이 아니라 평가 후 후보 선택 예제다.
-- 모든 required 조건·제외·관측·대안 논리를 평가한 결과만 pass로 넣는다.
-- fingerprint 불일치/미평가/정책 누락은 후보를 내지 않는다.
WITH app_input AS (
    SELECT %(bundle)s::jsonb AS bundle, %(runtime)s::jsonb AS runtime
),
eligible AS (
    SELECT r->>'rule_id' AS rule_id,r->>'message_id' AS message_id,
        p->>'rule_group' AS rule_group,(p->>'priority')::integer AS priority,
        m->>'title' AS title,m->>'body' AS body
    FROM app_input i
    CROSS JOIN LATERAL jsonb_array_elements(i.bundle->'tables'->'coaching_rule') r
    JOIN LATERAL jsonb_array_elements(i.bundle->'tables'->'coaching_message') m
      ON m->>'message_id'=r->>'message_id'
    CROSS JOIN LATERAL (SELECT i.runtime->'policy'->(r->>'rule_id') AS p) policy
    WHERE i.bundle->'manifest'->>'contract_version'='mai_coaching_candidate/v1'
      AND i.bundle->'manifest'->'validation_errors'='[]'::jsonb
      AND i.runtime->>'source_fingerprint'=i.bundle->'manifest'->>'source_fingerprint'
      AND r->>'candidate_state'='requires_operating_evaluation'
      AND m->>'candidate_state'='requires_operating_evaluation'
      AND i.runtime->'message_evaluations'->>(r->>'message_id')='pass'
      AND i.runtime->'rule_evaluations'->>(r->>'rule_id')='pass'
      AND p->'enabled'='true'::jsonb
      AND nullif(p->>'rule_group','') IS NOT NULL
      AND p->>'priority' IS NOT NULL
), ranked AS (
    SELECT *,row_number() OVER(PARTITION BY rule_group ORDER BY priority,rule_id) AS rn
    FROM eligible
), unique_messages AS (
    SELECT *,row_number() OVER(PARTITION BY message_id ORDER BY priority,rule_id) AS msg_rn
    FROM ranked WHERE rn=1
)
SELECT rule_group,priority,rule_id,message_id,title,body
FROM unique_messages WHERE msg_rn=1
ORDER BY priority,rule_group,rule_id;
