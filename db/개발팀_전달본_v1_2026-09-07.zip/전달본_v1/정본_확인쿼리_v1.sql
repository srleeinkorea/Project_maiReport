-- 서버 health_knowledge에서 필요한 SELECT 블록만 실행한다.
-- DDL/DML 없음. 이 조회들은 운영 사용자 분류/임계 생성/사용 승인 기능이 아니다.

-- 1. 접속 DB와 migration 시점
SELECT current_database() AS database_name,max(version) AS latest_migration
FROM public.schema_migration;

-- 2. 전체 문구 재고. 행 수는 독립 코칭 목적 수나 사용 승인 수가 아니다.
SELECT population_condition,count(*) AS line_count
FROM public.coaching_line GROUP BY population_condition ORDER BY population_condition;

-- 3. 최신 문구 + 대상 계약. line_id를 바꿔 다른 문구도 확인한다.
SELECT l.line_id,l.headline,l.detail,l.population_condition,
       a.audience_scope_kind,a.target_user_classification,
       a.required_runtime_classifications,a.required_behavior_or_context_signals,
       a.exclusion_runtime_classifications,a.forbidden_kb_roles,a.note
FROM public.coaching_line l
JOIN public.final_coaching_audience_contract a USING(line_id)
WHERE l.line_id IN ('pneumonia_rise_slowly_after_lying',
                   'pneumonia_recovery_lower_intensity',
                   'dm_shift_walking_to_after_meals',
                   'aerobic_volume_is_not_the_lever')
ORDER BY l.line_id,a.audience_contract_id;

-- 4. 원본 권고별 허용 강도. fact 96의 NULL은 경로 없음이다.
SELECT f.fact_seq,f.measurement_target_key,f.quantity AS recommended_quantity,f.unit,
       f.population_age,f.population_condition,f.package_id,
       u.intensity_definition_id,u.quantity AS intensity_range,u.unit AS intensity_unit
FROM public.fact_effective f
LEFT JOIN public.measurement_target_intensity_usable u
  ON u.recommendation_package=f.package_id
 AND u.measurement_target_key=f.measurement_target_key
WHERE f.fact_seq IN (43,96,133,141,142,150,168,190)
ORDER BY f.fact_seq,u.intensity_definition_id;

-- 5. 왜 raw 배정을 바로 쓰면 안 되는가: 사용 불가 번역 판정.
SELECT b.measurement_target_key,b.intensity_definition_id,b.recommendation_package,
       b.verdict,b.equivalence_package_id,b.equivalence_span_id,b.note
FROM public.definition_borrowing b
WHERE b.measurement_target_key='moderate_intensity_aerobic_physical_activity'
  AND b.recommendation_package=(SELECT package_id FROM public.fact_effective WHERE fact_seq=96)
ORDER BY b.intensity_definition_id;

-- 6. 범위의 포함 여부. quantity 문자열과 flag를 함께 본다.
SELECT definition_id,quantity::text,unit,
       lower(quantity) AS lower_value,upper(quantity) AS upper_value,
       lower_inc(quantity) AS lower_inclusive,upper_inc(quantity) AS upper_inclusive,note
FROM public.measurement_definition ORDER BY definition_id;

-- 7. 이미 있는 걸음수 코칭.
SELECT cc.fact_seq,cc.position,l.line_id,l.headline,l.detail,f.population_age
FROM public.coaching_condition cc
JOIN public.coaching_line l USING(line_id)
JOIN public.fact_effective f USING(fact_seq)
WHERE f.measurement_target_key='daily_step_count'
ORDER BY cc.position,l.line_id;

-- 8. 고령자 원본 fact 재고와 실제 문구 연결을 구분한다.
SELECT f.fact_seq,f.measurement_target_key,f.quantity,f.unit,f.population_age,
       cc.position,cc.line_id
FROM public.fact_effective f LEFT JOIN public.coaching_condition cc USING(fact_seq)
WHERE lower(f.population_age)>=65
ORDER BY f.fact_seq,cc.position,cc.line_id;

-- 9. 혈압/혈당/체중 등: fact 단위 재고만으로 전체 코칭 지식을 판단하지 않는다.
SELECT unit,count(*) FROM public.fact_effective GROUP BY unit ORDER BY unit;
SELECT a.line_id,a.audience_scope_kind,a.target_user_classification,
       a.required_behavior_or_context_signals,a.forbidden_kb_roles
FROM public.final_coaching_audience_contract a
WHERE a.line_id LIKE 'bp_htn_%' OR a.line_id LIKE 'dm_%' OR a.line_id LIKE '%weight%'
ORDER BY a.line_id;

-- 10. 수면 관찰/축 입력과 sample 원본.
SELECT * FROM public.coaching_axis_observation_rule ORDER BY fact_seq;
SELECT * FROM public.coaching_axis_event_requirement ORDER BY fact_seq,event_kind;
SELECT * FROM public.coaching_line_sample_requirement ORDER BY line_id,requirement_kind;

-- 11. target의 bout 연결. 총량 필터 적용 여부까지 자동 결정하는 표가 아니다.
SELECT a.measurement_target_key,a.bout_fact_seq,f.quantity,f.unit,f.package_id
FROM public.measurement_target_activity a LEFT JOIN public.fact_effective f ON f.fact_seq=a.bout_fact_seq
WHERE a.bout_fact_seq IS NOT NULL ORDER BY a.measurement_target_key;

-- 12. 원본 OR 그룹. 근거 문장과 member를 함께 보존한다.
SELECT group_id,package_id,span_id,array_agg(fact_seq ORDER BY fact_seq) AS members
FROM public.fact_alternative GROUP BY group_id,package_id,span_id ORDER BY group_id;

-- 13. line gate의 입력/미지원 조건/금지 역할.
SELECT r.line_id,r.note AS line_requirement_note,g.*
FROM public.coaching_line_gate_requirement r
JOIN public.coaching_gate_contract g USING(gate_contract_id)
WHERE r.line_id='general_inactivity_gap_move_prompt'
ORDER BY r.gate_contract_id;

-- 14. 폐렴 문구의 원칙·construct·device 맥락. signal을 수치 목표로 바꾸지 않는다.
SELECT line_id,principle_id,trace_role,criteria_keys,trace_construct_ids,
       trace_normalized_signal_keys,trace_device_data_natures,support_decision,boundary_note
FROM public.coaching_line_guideline_principle_criteria_trace
WHERE line_id IN ('pneumonia_rise_slowly_after_lying','pneumonia_recovery_lower_intensity')
ORDER BY line_id,trace_id;

-- 15. 지지 claim과 내부 맥락 claim을 구분해 원본을 찾아간다.
WITH claim_refs AS (
    SELECT line_id,claim_id,'line_support'::text AS use_role FROM public.coaching_line_claim
    UNION ALL
    SELECT line_id,claim_id,use_role FROM public.coaching_line_context_claim
)
SELECT r.line_id,r.use_role,c.claim_id,c.status,c.statement,
       b.construct_id,b.package_id,b.span_id,b.note
FROM claim_refs r JOIN public.behavior_signal_claim c USING(claim_id)
LEFT JOIN public.behavior_signal_construct b USING(claim_id)
WHERE r.line_id='general_daily_steps_below_7000_reconnect'
ORDER BY r.use_role,c.claim_id,b.construct_id;

-- 16. 제품 제외 목록. KDB 보존과 제품 포함을 구분한다.
SELECT line_id,product_candidate_state,include_in_kdb_server_migration,
       include_in_product_usable_seed,requires_quality_review_before_product_use,
       boundary_state
FROM public.mai_kdb_server_migration_quality_gate_matrix ORDER BY line_id;
