# 개발팀 전달본 v1 — 현재 서버 지식DB 기준

작성: 2026-09-07. 원본 `지식코칭_maiReport_전달테이블_설계_claude.md`와
`지식DB_전달테이블_추출_claude.sql`을 대체하는 **수정 전달본**이다.
개발팀은 서버 지식DB를 직접 조회할 수 있다는 전제로 작성했다.

이 폴더의 SQL과 설명서를 함께 사용한다. 기존 샘플 INSERT나 기존 5개 테이블 DDL에
새 결과를 섞어 넣지 않는다. 과거 검토 보고서는 수정 이유를 확인하는 참고자료다.

## 1. 전달 목적과 사용 가능 범위

서버 지식DB가 가진 현재 코칭 문구, 적용 조건, 허용 측정 방법을 운영 DB가 소비할 수 있는
5개 데이터 테이블로 추출한다. 문구가 기대는 내부 근거를 운영에서 다시 판정할 필요는 없다.
다만 **추출 완료는 사용자에게 발송할 수 있다는 뜻이 아니다.** 실제 사용자 맥락·데이터 품질과
노출 정책을 평가하는 코드는 운영 측이 구현한다.

이번 수정본에서 제공하는 것은 다음과 같다.

- 전체 coaching_line 중 현재 명시적 제품 제외 대상을 뺀 후보와, 제외 대상의 별도 기록.
- 각 후보의 대상·행동 맥락·제외 조건·gate·criteria·근거 역할.
- 권고별 허용 신호, 원래 숫자 구간과 경계 포함 여부, 관찰 규칙, 원본 대안(OR) 관계.
- SQL 추출·무결성 검증·JSON/운영 INSERT 생성 도구와 운영 선택 예제.
- 운영에서 정할 항목과 DB가 이미 정한 항목의 구분.

이번 산출물은 **후보 계약 추출 및 연동 개발에 사용할 수 있다.** 사용자별 조건 평가기,
디바이스 집계 어댑터, 실제 노출 정책은 운영 코드와 함께 구현·검증해야 한다.
고정 문구를 만들거나 새 의학적 판정을 추가하지 않았고, 서버 DB도 변경하지 않았다.

## 2. 파일과 실행 순서

| 파일 | 실행 대상 / 역할 |
|---|---|
| `지식DB_전달추출_v1.sql` | 서버 KDB. 순수 SELECT 한 문장, 한 행의 bundle JSONB 반환 |
| `export_contract.py` | 서버 읽기 전용 접속, 검증, JSON/운영 INSERT 파일 생성. DB 적재는 실행하지 않음 |
| `운영DB_테이블_v1.sql` | **운영 DB 전용** 최초 DDL. 별도 `maireport_kdb_v1` 스키마 생성 |
| `운영_선택예제_v1.sql` | 운영 평가 결과가 주어졌을 때 게이트 통과 후 순위·중복 제거를 수행하는 예제 |
| `정본_확인쿼리_v1.sql` | 서버 KDB에서 분야별 근거·계약·공백을 직접 확인하는 조회 모음 |
| `test_contract.py` | 서버 읽기 전용 회귀 검증. DB 변경 없이 실패 사례 포함 |

### 서버 추출

현재 정본 DB 이름은 `health_knowledge`다. 샘플 DB 이름 `maireport-knowledge`와
localhost 접속 예제를 재사용하지 않는다. 접속 비밀은 이 전달본에 포함하지 않는다.

repo 안에서는 `지식DB/db/.env`의 PG 설정을 사용한다. `.env.server`가 있으면 실제 DSN과도
비교한다. 이 폴더만 전달받은 경우 `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD`를
서버 접속 정보로 설정한다. 필수 접속값이 없으면 로컬 기본값으로 대체하지 않고 실패한다.
Python 의존성은 psycopg2, 테스트에는 pytest가 필요하다.

```bash
cd 운영검토/전달본_v1
python3 export_contract.py --check
python3 export_contract.py --output candidate_contract.json --sql-output operations_insert.sql
python3 -m pytest -q test_contract.py
```

이미 있는 출력 파일은 덮어쓰지 않는다. 갱신할 때 새 파일명을 쓴다.
Python 없이 pgAdmin/DBeaver에서 `지식DB_전달추출_v1.sql`만 실행해도 같은 bundle을 조회한다.
`manifest.validation_errors`가 비어 있지 않으면 `tables`가 NULL이며 전달/적재하지 않는다.
Python 도구는 구조·참조도 추가 검증하고, 오류 시 파일을 만들지 않고 종료 코드 1을 반환한다.

### 운영 DB에 보관

1. 운영 DB에서 `운영DB_테이블_v1.sql`을 최초 1회 실행한다.
2. 같은 운영 DB에서 생성된 `operations_insert.sql`을 실행한다.
3. 앱은 명시적으로 선택한 `release_id`의 5개 테이블을 함께 읽는다.

둘 다 KDB 이름 `health_knowledge`에서는 실행을 거부한다. 기존 운영 테이블을 DROP/TRUNCATE하지
않으며, 이전 release도 삭제하지 않는다. 같은 release를 중복 적재하면 PK 오류로 전체 rollback한다.
최초 DDL 재실행도 기존 테이블 오류로 rollback한다. 기존 운영 schema를 바꾸고 싶다면
개발팀 migration으로 관리한다. 이 작업에서는 운영 DB가 제공되지 않아 실제 운영 적재는 실행하지 않았다.

5개 데이터 테이블 외에 `coaching_contract_release` 한 개가 버전 메타데이터를 보관한다.
과거 버전으로 되돌릴 때는 앱이 참조하는 release 선택을 바꾼다. “가장 최근 시각”을 자동 승인으로
쓰지 않는다. 문구·규칙·신호를 서로 다른 release에서 섞으면 안 된다.

## 3. 현재 정본에서 확인된 차이

아래는 검증 시점의 결과다. 새 데이터가 추가되면 `--check`로 다시 얻는다.

| 항목 | 기존 초안 | 현재 v1 |
|---|---:|---:|
| 문구 | 샘플 15개 가정 | 218개 후보 + 2개 명시적 제품 제외 |
| 규칙 | 20 | 239 |
| 지표/측정 계약 | 9개 별칭 | fact 15개 + sample 계약 1개 |
| 신호 정의 | 18 | 27 |
| 기본 기술 입력 | 8 | 8; 별도 대상·상황 조건은 각 문구 계약에 포함 |
| 전체 문구 재고 | 전달본과 혼동 | 220; 사용 승인 수 또는 독립 코칭 목적 수가 아님 |

현재 `general`, `diabetes`, `pneumonia`, `chronic_conditions_or_disabilities` 값을 그대로 보존한다.
이 코드를 곧바로 확진 질환이나 특정 회복 단계로 해석하지 않는다. 예를 들어 만성질환 코드는
더 구체적인 대상 계약과 함께 읽어야 하고, `pneumonia`를 일괄 `pneumonia_recovery`로 바꾸지 않는다.

현재 문구는 과거 샘플과 다르다. `dm_few_active_days_try_short_bouts`가 과거 “1분씩 아주 힘들게”를
말했다고 해서 지금도 같은 의도의 문구라고 판단하면 안 된다. 제목·본문은 매번 DB에서 추출한다.
행이 늘어도 상위 행동 목적과 그 안의 활동 예시를 구분한다. 문구 수를 독립 코칭 수로 세지 않는다.

## 4. 테이블 5개의 새 계약

정확한 SQL 타입·PK·FK는 `운영DB_테이블_v1.sql`이 정의한다.
bundle의 각 배열은 동일 이름의 테이블 행이다. 적재 시 모든 행에 `release_id`가 추가된다.
PK는 `(release_id, 각 테이블 식별자)`이고 signal은 metric_key도 포함한다.

### 4.1 coaching_input — 기본 기술 입력

| 필드 | 의미 |
|---|---|
| `input_key` | `event:sleep_session`, `measurement:MET`, `profile:age` 같은 namespaced 키 |
| `input_kind`, `native_key` | event/measurement/profile/sample 구분과 원래 키 |
| `question_text_ko`, `freshness_hours`, `available_now` | 모두 NULL로 전달. 운영 질문·만료·실제 수집 가능 여부는 개발팀 설정 |
| `adapter_owner` | `operating_system`; 원자료를 이 입력으로 만드는 책임 |

이 8개는 기술 입력 목록이다. 모든 문구의 상황 요구가 8개로 줄었다는 뜻이 아니다.
예를 들어 최근 누워 있음, 복약 맥락, 외래 상황 등은 `coaching_message`의 audience/gate/criteria에
보존돼 있다. 그것들을 임의의 질문 문장이나 확진 boolean으로 바꾸지 않았다.

### 4.2 coaching_metric — 권고별 측정 계약

| 필드 | 의미 |
|---|---|
| `metric_key` | `fact:133`, `sample:short_ambulatory_mvpa_proxy`; 이름이 비슷해도 합치지 않는 식별자 |
| `metric_kind`, `native_target`, `unit` | fact 축/sample 관찰, 원래 측정 대상, 원래 단위 |
| `source_fact_seq`, `recommendation_package` | 권고와 허용 정의를 연결하는 원본 키 |
| `reference_quantity` | 원본 권고 범위: min/max, 양쪽 포함 여부, range 문자열, range_type |
| `population` | 원본 condition/region/연령 범위와 경계 포함 여부 |
| `observation_rules` | 해당 축의 관찰 규칙 원문 필드. 수면 7일/5밤/과반 규칙 포함 |
| `axis_event_requirements` | 축 계산 자체에 필요한 모든 사건. line 사건과 구분 |
| `target_bout_reference` | 측정 대상에 연결된 bout fact와 범위. 아래 지속시간 주의사항 참조 |
| `sample_contract` | 현재 알려진 sample의 1분 이상·10분 미만, 단일 샘플, 병합 금지 등 |
| `alternative_groups` | 원본 fact_alternative의 OR 묶음·모든 member_metric_keys·근거 위치 |
| `measurement_state` | 허용 측정 경로 있음 / `no_usable_measurement_path` |
| `calculation_state` | `operating_adapter_required`; 앱 계산 구현/검증 상태와 혼동하지 않음 |
| `source_ref` | 원본 fact·package·mention·권위기관·버전·변환 정보 |

NULL 연령 하한·상한은 그 fact에 값이 없다는 뜻이다. 새로운 성인 기본값을 만들지 않는다.
실제 대상 판단은 문구 계약도 함께 따른다. 연령 제한이 있는데 나이를 모르면 평가 불가다.

### 4.3 coaching_metric_signal — 그 권고에 허용된 측정 방법

| 필드 | 의미 |
|---|---|
| `metric_key`, `signal_key` | 지표와 정의의 복합 식별자. 전역 met/cadence 우선순위로 통합하지 않음 |
| `signal_unit`, `signal_min`, `signal_max` | 신호 단위와 원본 강도 범위 |
| `min_inclusive`, `max_inclusive`, `source_range` | 경계 포함과 원래 range 표현 |
| `required_input_keys` | **해당 신호 경로를 선택했을 때** 함께 필요한 입력들 |
| `source_kind` | approved_definition / direct_observation / sample_requirement |
| `source_ref` | 권고 package와 정의/원문 위치 또는 직접 관찰 계약 |
| `selection_priority` | NULL. 허용 경로 안에서 출처·품질·일관성을 기준으로 운영이 선택 |

연결 정본은 `measurement_target_intensity_usable`이다. 원시
`measurement_target_intensity`를 바로 사용하면 차용/번역 불가 판정을 우회한다.

| 현재 지표 | 허용 경로 | 잘못된 처리 |
|---|---|---|
| `fact:133` | %HRmax만 있음 | MET/cadence로 대체해 150분 판정 |
| `fact:141` | MET 또는 cadence | fact:133과 같은 이름으로 합치기 |
| `fact:96` | 현재 사용 가능한 경로 없음 | %HRmax·MET를 임의로 붙여 살리기 |
| `fact:40` | 날짜가 있는 밤별 수면 시간 | 하루 대표값/단일 밤을 regular sleep 판정으로 사용 |
| `fact:190` | 출처 중복이 정리된 일별 총 걸음수 | 원시 구간 합산을 무조건 일별 총량으로 사용 |

`fact:96`의 규칙도 추적용으로 남지만 `blocked_no_usable_measurement_path` 상태다.
운영 선택 예제는 정책을 enabled로 주어도 이 규칙을 선택하지 않는다. 다른 허용 권고를
사용할 수 있는지는 그 권고에서 별도로 평가한다.

현재 fact:133의 정의 note가 말하는 최대심박수 식은 `220-나이`다. 이 경로를 구현한다면
구간 심박수를 `100×심박수/(220-나이)`로 계산하며 나이와 구간 심박수가 모두 필요하다.
하루 평균/최대 심박수로 대신하지 않는다. 이 식은 현재 해당 정의에 연결된 어댑터 설명이며
다른 권고·개인 최대심박수 추정 모델에 무조건 재사용하는 공통 환산 규칙이 아니다.

### 4.4 coaching_message — 현재 문구와 의미 제한

| 필드 | 의미 |
|---|---|
| `message_id`, `title`, `body` | 현재 coaching_line 식별자·제목·본문 |
| `population_condition` | 원본 값. 운영 사용자 분류의 충분조건이 아님 |
| `topic` | NULL. 개발팀 분류표가 없으므로 추출기가 임의 주제를 붙이지 않음 |
| `audience_contracts` | 대상 분류·필요 행동/상황·제외·금지 역할·설명 전체 |
| `support_claims` | 문구 지지 claim과 현재 상태. 원문 문구를 임의 확장하는 허가는 아님 |
| `context_claims` | 내부 맥락 claim, use_role, note. 화면에 생리 기전/효과를 추가하는 재료로 오해하지 않음 |
| `criteria_traces` | 문구→원칙→construct/device 맥락 연결, criteria_keys, 경계 설명 |
| `gate_contracts` | line gate와 해당 계약 전체. accepted_sources·unavailable_when·blocked_roles 등 보존 |
| `event_requirements`, `sample_requirements` | 문구 자체가 요구하는 모든 사건/sample |
| `candidate_state` | `requires_operating_evaluation`; is_active=true와 다름 |
| `source_ref` | line_id와 명시적 제품 제외 여부 |

`audience_contracts` 안의 `required_behavior_or_context_signals` 등은 DB의 의미 계약이다.
`optional_...`나 `no_..._boundary`처럼 선택적 참고·금지 경계를 표현하는 항목도 있다.
**모든 문자열을 무조건 사용자 질문이나 센서 필수값으로 바꾸는 AND 구현은 하지 않는다.**
각 key와 note를 운영 어댑터에서 해석하고, 미지원·미확인 항목이 실제 적용을 제한하면 pass를 내지 않는다.
의미가 불분명한 key는 해당 원칙/대상 계약을 조회해 확인한다. 이름만 보고 새 임계나 판정을 만들지 않는다.

제품 제외 두 문구는 message/rule에서 빠지고 `manifest.excluded_messages`에 원본 사유와 함께 남는다.
이 목록에 없다는 사실만으로 다른 문구의 품질·상황 적합성이 모두 승인됐다는 뜻은 아니다.

### 4.5 coaching_rule — 숫자 또는 상황 계약에 연결되는 후보

| 필드 | 의미 |
|---|---|
| `rule_id`, `message_id` | 원본 축/position/문구 조합의 고유 ID와 문구 FK |
| `trigger_type` | metric_range / sample_observed / context_contract |
| `metric_key`, `source_position` | 참조 측정 계약과 원본 below/within/above |
| `value_min`, `value_max`, `min_inclusive`, `max_inclusive` | 이 규칙이 해당하는 숫자 범위 |
| `all_input_keys` | 문구 event/sample + 해당 축 event 전체. 입력 하나만 남기는 LIMIT 1 없음 |
| `candidate_state` | 운영 평가 필요 또는 측정 경로 부재로 차단 |
| `rule_group`, `priority` | NULL. 운영의 노출 정책으로 별도 설정 |
| `source_ref` | 원본 fact/position/line 또는 sample 계약 |

숫자 조건이 없는 문구는 `context_contract`다. **조건이 없다는 뜻이 아니라 메시지의
audience/gate/criteria로 평가한다는 뜻**이다. 여러 규칙이 같은 문구를 가리킬 수 있으며,
상황 계약을 통과한 후 최종 문구 ID로 중복을 제거한다.

## 5. 계산과 판정에서 바뀐 부분

### 경계 포함을 보존한다

하한이 있으면 `min_inclusive=true`일 때 `>=`, false일 때 `>`를 쓴다.
상한이 있으면 `max_inclusive=true`일 때 `<=`, false일 때 `<`를 쓴다.
하한/상한 NULL이면 그 방향 비교를 하지 않는다. 포함 플래그만 보고 NULL을 0으로 바꾸지 않는다.

| 정본 | v1 의미 |
|---|---|
| MET `[3,5.9]` | 3 이상 **5.9 이하** |
| %HRmax `[50,70]` | 50 이상 **70 이하** |
| fact 150 `(,2]`의 above | **2 초과**. 정수 3으로 변환하지 않음 |
| sample `[1,10)`분 | 1분 이상 10분 미만 |

### 관찰 창과 지속시간을 구분한다

수면은 `observation_rules`의 `majority_below_lower_bound`를 그대로 사용한다.
최근 7일에서 최소 5밤이 관찰되고, 관찰 밤 중 fact의 하한보다 짧은 비율이 0.5를 **초과**해야 한다.
`[6,6,6,9,9]`는 평균 7.2시간이어도 5밤 중 3밤이 7시간 미만이다. 평균 <7 비교로 대체하지 않는다.

주간 창의 날짜/시간대·최소 관찰량, 관찰 누락 처리 등은 운영 정의가 필요하다.
기존 초안의 7/7·14/2를 근거값처럼 전달하지 않는다. 부분 관찰에서 누적이 목표 이상인 경우와
목표 미만인 경우는 대칭이 아니다. 모르는 시간을 활동 0으로 채우지 않는다.

`target_bout_reference`는 DB의 target→bout fact 관계를 손실 없이 전달한 것이다.
현재 fact:141에도 10분 참조가 있지만, 이를 자동으로 주간 총량의 모든 짧은 구간을 버리는
필터로 적용하지 않는다. 참조 러너는 주간 총량과 활동일/세션 자격을 다르게 계산한다.
총량 집계와 세션 자격의 범위를 구분해 운영 어댑터 계약을 명시해야 한다.
v1은 상충하는 의미를 임의로 확정하지 않으며 `calculation_state`를 구현 필요로 남긴다.

### 운동 간격은 “최근 두 세션의 시각 차이”로 끝내지 않는다

참조 러너 `coaching/state.py`의 `max_gap_days`는 운동한 날짜의 집합과 기준일을 사용한다.
닫힌 구간은 연속 운동일 사이의 운동 없는 날 `(다음날짜-이전날짜).days-1`,
마지막 열린 구간은 `(기준일-마지막운동일).days`, 결과는 이들 중 최대값이다.
기준점이 없으면 판정 불가다. 마지막 운동일 한 번과 기준일이 있으면 열린 공백은 계산할 수 있다.

이 날짜 계약을 채택하면 날짜 경계/시간대/현재 일자의 관찰 상태도 함께 정한다.
경과시간(예: 2.5일) 방식으로 바꾸려면 같은 지표라고 부르지 말고 의미 차이를 확인해야 한다.
v1은 원본 `>2`를 보존하며, 운영 어댑터가 다른 정의를 몰래 대입할 수 있게 하지 않는다.

### OR와 노출 우선순위를 분리한다

`alternative_groups`는 근거가 말한 중강도 **또는** 고강도 관계다.
원본 그룹 내 하나를 충족한 사용자를 다른 갈래가 below라는 이유로 전체 부족으로 판단하지 않는다.
갈래가 미평가인 상태를 미달로 만들지도 않는다. 이 의미 판단 후에 문구 그룹/우선순위를 적용한다.
`중강도 + 2×고강도` 환산은 이번 추출에 넣지 않았다. 별도의 승인된 계산 계약이 없으면 만들지 않는다.

### activeMinutes는 앱 코드 확인 후 연결한다

1분 bin의 100걸음 임계가 같다는 것만으로 `activeMinutes`를 모든 권고에 연결할 수는 없다.
출처 중복·bin 경계·관찰 누락·폴백 여부와 해당 권고의 허용 경로를 검증한다.
하루 총 걸음수/100 폴백은 사용하지 않는다. 적격한 일별 MVPA 분이 있으면 주간 MVPA 합에
중/고강도 분리가 항상 필요한 것은 아니지만, 별도 중강도·고강도 축과 환산 총량에는 구분이 필요하다.
앱 코드가 이 repo에 없어 현재 수집 가능 여부는 NULL로 남겼다.

## 6. 운영 선택 예제의 입출력

`운영_선택예제_v1.sql`은 `%(bundle)s`, `%(runtime)s`의 psycopg 파라미터 형식이다.
`bundle`, `runtime` 두 값을 JSON 문자열로 바인딩한다. 문자열 치환으로 SQL을 조립하지 않는다.

운영이 제공할 runtime 형식:

```json
{
  "source_fingerprint": "추출 manifest와 같은 값",
  "message_evaluations": {
    "pneumonia_rise_slowly_after_lying": "pass"
  },
  "rule_evaluations": {
    "context:pneumonia_rise_slowly_after_lying": "pass"
  },
  "policy": {
    "context:pneumonia_rise_slowly_after_lying": {
      "enabled": true,
      "rule_group": "서비스가 정한 그룹",
      "priority": 20
    }
  }
}
```

위 pass는 형식 예시다. 실제 사용자는 운영이 아래 평가를 완료했을 때만 pass를 넣는다.

- `message_evaluations`: 해당 문구의 audience·gate·criteria·근거 사용 경계·제외 조건 전체 평가.
- `rule_evaluations`: 해당 규칙의 입력, 허용 측정 경로, 대상 범위, 구간, 관찰, sample, OR 관계 평가.
- context_contract도 자동 pass하지 않는다. 숫자 비교가 없어도 관련 상황/입력 조건을 확인한다.
- 평가 결과는 pass/fail/unknown이다. 누락·미지원은 unknown이며, 예제는 pass만 선택한다.

예제는 버전 일치와 평가/정책을 확인한 후 그룹별 순위를 매긴다. 1등 문구가 상황 평가에서
탈락했다면 2등을 선택할 수 있다. 마지막으로 같은 문구를 중복 제거한다.
입력 맥락을 임의로 생성하거나 질환·회복 여부를 판단하는 코드는 포함하지 않는다.

선택 예제는 평가 뒤의 동작을 보이는 작은 참조 구현이다. 운영 DB에서는 같은 release의
관계형 테이블을 조인해 구현해도 된다. 전체 JSON을 매 사용자 요청마다 서버 KDB에서 읽지 않는다.
규칙/문구 계약은 운영에 캐시하고, KDB는 버전 갱신과 근거 조회 시 사용한다.

## 7. 기존 개발팀 요청서 항목별 업데이트

| 기존 절 | 개발팀 반영 내용 |
|---|---|
| §1~2 목적·평탄화 | 5개 데이터 테이블 유지. 같은 임계라는 이유만으로 권고 병합은 중단 |
| §3 구간 규약 | 반열린 구간 통일 대신 min/max 포함 플래그 사용 |
| §4 테이블 | 이 폴더의 DDL/필드 정의로 교체. release FK 및 대상 계약 추가 |
| §5 샘플 | 현재 서버 SELECT로 생성. 과거 15개 문구·20개 규칙 고정값 제거 |
| §6 INSERT·런타임 | 생성 도구와 운영 선택 예제로 교체. 조건 평가 전 순위 선정 금지 |
| §7 추가 수집 | 실제 앱 어댑터 점검 후 입력별 available_now 설정. DB에 없는 값을 의학팀 확정값으로 표기하지 않음 |
| §8 의학팀 질문 | 아래 현재 DB 기준 답변 적용 |
| §9 전달·갱신 | 버전별 JSON/INSERT, 별도 schema, 오류 시 산출 차단, release 명시 선택 |
| §10 체크리스트 | 아래 수용 기준으로 교체 |

### 기존 §8에 대한 현재 답변

| 항목 | 현재 DB 기준 답변 |
|---|---|
| 8-1 걸음수 문구 | 이미 있다. fact:190의 below/within 두 문구가 v1 규칙에 포함된다. 기존 문구의 대상·표현 경계를 사용한다. |
| 8-2 혈압·혈당·체중 | 해당 수치 임계 fact가 없다는 것과 관련 코칭 지식이 없다는 것은 다르다. 확인쿼리에서 대상 계약·claim·construct 역할을 함께 본다. 수집 가능하다는 이유로 새 진단 임계를 만들지 않는다. |
| 8-3 강도 병합 | 허용 정의 뷰로 제한. fact:96 차단·fact:133 심박수만·fact:141 MET/cadence를 확인한다. OR 그룹은 정본에서 추출한다. |
| 8-4 관찰·구간 | 수면은 정본 규칙, 다른 창/관찰 정책은 운영 설정. 경계 포함·간격 정의는 §5 참조. |
| 8-5 그룹·우선순위 | 운영 소유. 현재 문구 의미·적용 맥락을 보고 정한다. 동일 조건의 고정 우선순위가 하위 문구를 영구히 가리지 않게 검증한다. |
| 8-6 고령자 | fact 31만 존재하는 것이 아니다. 연령 범위 조회와 실제 문구 연결을 구분한다. 모든 고령자용 새 문구를 이번에 만드는 것은 아니다. |
| 8-7 근력운동 | 근거 재고와 사용 가능한 문구/질문 입력 계약을 먼저 확인한다. 질문을 통한 확장은 가능하지만 수집 항목만으로 근거·조건을 대신하지 않는다. |
| 8-8 폐렴 명칭 | 원본 pneumonia 보존. 외래·회복·행동 상황 등은 audience/criteria의 운영 분류로 따로 평가한다. |

## 8. 검증과 개발팀 수용 기준

현재 서버에 대한 추출 구조 검증과 읽기 전용 회귀 테스트를 제공한다.
고정 총량을 통과 기준으로 삼지 않고 원본과 후보 집합·문구·계약·경계가 일치하는지 확인한다.
미지원 sample 해석이나 빈 소스는 오류이며 payload를 만들지 않는다.

마지막 확인(2026-09-07): 서버 추출 검증 오류 0, 정본 확인쿼리 전체 실행 성공,
전용 테스트 **16 passed**. 운영 DDL의 필드 대응과 INSERT/JSON 파일 생성도 검사했다.

개발팀이 추가로 확인할 수용 기준:

| 사례 | 기대 결과 |
|---|---|
| fact:133에 MET/cadence만 있음 | 해당 축은 평가 불가; 다른 허용 축과 구분 |
| fact:96을 운영 정책으로 enabled 처리 | 여전히 선택되지 않음 |
| 강도 5.9 MET / 70%HRmax | 원본 정의의 포함 플래그대로 계산 |
| 59초 / 60초 / 10분 sample | 제외 / 포함 가능 / 제외; 강도 조건도 함께 검사 |
| `[6,6,6,9,9]` 수면 | 관찰 밤 과반 부족; 평균 비교로 대체하지 않음 |
| 수면 4밤 또는 정확히 절반 부족 | 관찰 부족 / 과반 조건 미충족 |
| 마지막 운동 후 계속 휴식 | 열린 공백 증가가 반영됨 |
| 폐렴 코드만 있고 최근 휴식 맥락 없음 | 관련 문구의 평가를 pass하지 않음 |
| 1등 문구 게이트 실패·2등 통과 | 2등 선택 가능 |
| release fingerprint 불일치 | 선택 결과 없음 |
| 제품 제외 문구 | 후보 테이블·선택 결과에 없음; manifest 제외 목록에는 있음 |
| 새 문구/새 sample 계약 | 새 문구는 조건과 함께 자동 추출; 새 sample 해석 미지원이면 추출 오류 |

테스트 범위는 추출 정합성과 선택 예제다. 앱의 데이터 처리/사용자 분류/의학적 타당성을
검증한 것으로 확대하지 않는다. 운영 DDL/INSERT는 생성했으며 실제 운영 DB 적재·부하 검증은
개발팀 환경에서 수행한다. 전달본 전체를 받아야 테스트와 생성 도구를 실행할 수 있다.

`source_fingerprint`는 source manifest와 5개 테이블 내용의 변경 식별자(MD5)다.
보안 서명은 아니다. 생성 시각은 fingerprint에서 제외되므로 데이터·migration 집합이 같으면
같은 ID가 나온다. 운영의 입력/정책 변경 버전은 별도로 관리한다.

## 9. 개발팀이 정할 부분

DB가 정한 구간·허용 측정 경로·대상/제외/금지 역할은 변경하지 않고 가져간다.
다음은 개발팀이 실제 수집 구조와 화면 정책에 맞춰 설정한다.

- 센서 출처 정리, 시간대·관찰창, 샘플/세션 집계 어댑터와 데이터 신뢰도.
- 상황 계약 key별 평가 방법, 미확인 상태 처리, 추가 질문과 만료.
- 지원할 코칭 범위, topic, rule_group, priority, 반복 억제·순환·화면 개수.
- 운영에서 사용할 release와 배포/되돌리기 절차.

이 선택을 위해 DB에 새 근거를 만들거나 기존 문구를 임의 수정할 필요는 없다.
새로운 의미·임계·질환 판단이 필요한 경우에만 지식DB 구축 작업으로 별도 요구를 보낸다.
