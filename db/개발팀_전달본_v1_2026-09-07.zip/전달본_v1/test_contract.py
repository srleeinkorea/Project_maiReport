"""Focused read-only server tests for the handoff contract, not medical validation."""
import copy
import json
import re
import sys
from decimal import Decimal
from pathlib import Path

import pytest

from export_contract import SQL_PATH, build_insert_script, connect_server, fetch_bundle, main, validate_bundle


class ReadOnlySource(tuple):
    def __repr__(self):
        return '<read-only canonical server fixture; connection details hidden>'


@pytest.fixture(scope='module')
def source():
    conn = connect_server()
    try:
        yield ReadOnlySource((conn, fetch_bundle(conn)))
    finally:
        conn.rollback()
        conn.close()


def table(bundle, name):
    return bundle['tables'][name]


def test_bundle_integrity_and_readonly(source):
    conn, bundle = source
    assert validate_bundle(bundle) == []
    with conn.cursor() as cur:
        cur.execute("SELECT current_setting('transaction_read_only')")
        assert cur.fetchone()[0] == 'on'


def test_exact_candidate_set_and_copy_from_source(source):
    conn, bundle = source
    with conn.cursor() as cur:
        cur.execute("""SELECT l.line_id,l.headline,l.detail FROM coaching_line l
            WHERE NOT EXISTS(SELECT 1 FROM mai_kdb_server_migration_quality_gate_matrix q
                WHERE q.line_id=l.line_id AND q.include_in_product_usable_seed IS NOT TRUE)""")
        expected = set(cur.fetchall())
    actual = {(r['message_id'], r['title'], r['body']) for r in table(bundle, 'coaching_message')}
    assert actual == expected
    assert {'pneumonia_short_sleep_plant_one_pot', 'pneumonia_long_knitting_yarn_put_away'}.isdisjoint(r[0] for r in actual)


def test_semantic_contracts_are_preserved(source):
    conn, bundle = source
    for row in table(bundle, 'coaching_message'):
        with conn.cursor() as cur:
            for source_table, key, field in [
                ('final_coaching_audience_contract','audience_contract_id','audience_contracts'),
                ('coaching_line_guideline_principle_criteria_trace','trace_id','criteria_traces'),
            ]:
                cur.execute(f"SELECT to_jsonb(t)-'created_at' FROM {source_table} t WHERE line_id=%s ORDER BY {key}", (row['message_id'],))
                assert row[field] == [r[0] for r in cur.fetchall()]


def test_approved_measurement_routes_not_metric_aliases(source):
    _, bundle = source
    signals = table(bundle, 'coaching_metric_signal')
    assert {s['signal_unit'] for s in signals if s['metric_key']=='fact:133'} == {'percent_hrmax'}
    assert {s['signal_unit'] for s in signals if s['metric_key']=='fact:141'} == {'MET','steps_per_min'}
    assert not [s for s in signals if s['metric_key']=='fact:96']
    assert {r['candidate_state'] for r in table(bundle, 'coaching_rule') if r['metric_key']=='fact:96'} == {'blocked_no_usable_measurement_path'}


def test_all_definition_values_and_endpoints_match_source(source):
    conn, bundle = source
    with conn.cursor() as cur:
        for s in table(bundle, 'coaching_metric_signal'):
            if s['source_kind'] != 'approved_definition':
                continue
            cur.execute("SELECT quantity FROM measurement_definition WHERE definition_id=%s", (s['signal_key'],))
            q = cur.fetchone()[0]
            lo = None if s['signal_min'] is None else Decimal(str(s['signal_min']))
            hi = None if s['signal_max'] is None else Decimal(str(s['signal_max']))
            assert lo == q.lower and hi == q.upper
            assert s['min_inclusive'] == q.lower_inc and s['max_inclusive'] == q.upper_inc
    met = next(s for s in table(bundle,'coaching_metric_signal') if s['metric_key']=='fact:43' and s['signal_unit']=='MET')
    assert met['signal_max'] == 5.9 and met['max_inclusive'] is True


def test_sample_limits_and_no_invented_age(source):
    _, bundle = source
    m = next(m for m in table(bundle,'coaching_metric') if m['metric_kind']=='sample_observation')
    assert m['population'] is None
    s = m['sample_contract']
    assert s['min_bout_minutes']==1 and s['min_inclusive'] is True
    assert s['max_bout_minutes']==10 and s['max_inclusive'] is False
    assert s['single_sample_only'] is True and s['merge_samples'] is False
    assert s['daily_total_steps_allowed'] is False


def test_gap_keeps_open_boundary_and_sleep_axis_input(source):
    _, bundle = source
    gap = next(r for r in table(bundle,'coaching_rule') if r['metric_key']=='fact:150')
    assert gap['value_min']==2 and gap['min_inclusive'] is False
    sleep = next(r for r in table(bundle,'coaching_rule') if r['metric_key']=='fact:40')
    assert 'event:sleep_session' in sleep['all_input_keys']
    m = next(m for m in table(bundle,'coaching_metric') if m['metric_key']=='fact:40')
    obs = m['observation_rules'][0]
    assert (obs['window_days'],obs['min_observed_count'],obs['below_fraction_gt'])==(7,5,0.5)


def test_bout_reference_is_not_silently_applied_to_totals(source):
    _, bundle = source
    m = next(m for m in table(bundle,'coaching_metric') if m['metric_key']=='fact:141')
    assert m['target_bout_reference']['min']==10
    assert m['target_bout_reference']['application_scope']=='target_relation_not_automatic_total_volume_filter'
    assert m['calculation_state']=='operating_adapter_required'


def test_fail_on_removed_contract_or_foreign_key(source):
    _, bundle = source
    broken = copy.deepcopy(bundle)
    broken['tables']['coaching_message'][0]['audience_contracts'] = []
    assert any(e['code']=='missing_message_contract' for e in validate_bundle(broken))
    broken = copy.deepcopy(bundle)
    broken['tables']['coaching_metric'] = []
    assert any(e['code']=='missing_metric_fk' for e in validate_bundle(broken))


def test_changed_sample_note_prevents_payload_export(source):
    conn, _ = source
    query = SQL_PATH.read_text().replace('SELECT DISTINCT s.requirement_kind, s.note',
        "SELECT DISTINCT s.requirement_kind, 'changed contract'::text AS note")
    with conn.cursor() as cur:
        cur.execute(query)
        broken = cur.fetchone()[0]
    assert broken['tables'] is None
    assert any(e['code']=='unsupported_sample_contract' for e in validate_bundle(broken))


def test_zero_messages_is_not_a_success(source):
    conn, _ = source
    query = SQL_PATH.read_text().replace('SELECT l.* FROM public.coaching_line l',
        'SELECT l.* FROM (SELECT * FROM public.coaching_line WHERE false) l')
    with conn.cursor() as cur:
        cur.execute(query)
        broken = cur.fetchone()[0]
    assert broken['tables'] is None
    assert any(e['code']=='no_exportable_messages' for e in validate_bundle(broken))


def test_insert_generation_is_versioned_and_preserves_source(source):
    conn,bundle=source
    script=build_insert_script(conn,bundle)
    assert script.startswith('-- Operations DB only.')
    assert script.endswith('COMMIT;\n')
    assert "current_database()='health_knowledge'" in script
    assert 'TRUNCATE ' not in script and 'DROP SCHEMA' not in script
    # Every generated INSERT is counted by its schema-qualified prefix, not by
    # semicolons that can legitimately occur within Korean copy / JSON strings.
    assert script.count('INSERT INTO "maireport_kdb_v1".') == 1 + sum(bundle['manifest']['table_counts'].values())
    assert bundle['manifest']['source_fingerprint'] in script
    ddl=(Path(__file__).parent/'운영DB_테이블_v1.sql').read_text()
    for name,rows in bundle['tables'].items():
        body=re.search(r'CREATE TABLE maireport_kdb_v1\.'+name+r' \((.*?)\n\);',ddl,re.S).group(1)
        ddl_columns=set(re.findall(r'^    (\w+) (?:text|integer|numeric|boolean|bigint|jsonb)\b',body,re.M))
        assert all(set(row)|{'release_id'} == ddl_columns for row in rows)
    broken=copy.deepcopy(bundle)
    broken['tables']['coaching_message'][0]['audience_contracts']=[]
    with pytest.raises(ValueError):
        build_insert_script(conn,broken)


def test_cli_creates_outputs_and_refuses_overwrite(tmp_path,monkeypatch,capsys):
    json_path,sql_path=tmp_path/'contract.json',tmp_path/'insert.sql'
    monkeypatch.setattr(sys,'argv',['export_contract.py','--output',str(json_path),'--sql-output',str(sql_path)])
    assert main()==0
    summary=json.loads(capsys.readouterr().out)
    bundle=json.loads(json_path.read_text())
    assert summary['validation_errors']==[] and validate_bundle(bundle)==[]
    assert sql_path.read_text().endswith('COMMIT;\n')
    original=json_path.read_bytes()
    with pytest.raises(FileExistsError):
        main()
    assert json_path.read_bytes()==original


def select(conn, bundle, runtime):
    with conn.cursor() as cur:
        cur.execute((Path(__file__).parent/'운영_선택예제_v1.sql').read_text(),
                    {'bundle':json.dumps(bundle),'runtime':json.dumps(runtime)})
        return [dict(zip([d.name for d in cur.description],r)) for r in cur.fetchall()]


def test_missing_context_and_stale_version_return_nothing(source):
    conn, bundle = source
    assert select(conn,bundle,{}) == []
    mid = 'pneumonia_rise_slowly_after_lying'
    rid = 'context:'+mid
    rt = {'source_fingerprint':'stale', 'message_evaluations':{mid:'pass'},
          'rule_evaluations':{rid:'pass'},'policy':{rid:{'enabled':True,'rule_group':'example','priority':1}}}
    assert select(conn,bundle,rt)==[]
    rt['source_fingerprint']=bundle['manifest']['source_fingerprint']
    assert len(select(conn,bundle,rt))==1
    rt['message_evaluations']={}
    assert select(conn,bundle,rt)==[]


def test_gate_filter_precedes_ranking(source):
    conn,bundle=source
    m1,m2='pneumonia_recovery_lower_intensity','pneumonia_rise_slowly_after_lying'
    r1,r2='context:'+m1,'context:'+m2
    rt={'source_fingerprint':bundle['manifest']['source_fingerprint'],
        'message_evaluations':{m1:'fail',m2:'pass'},'rule_evaluations':{r1:'pass',r2:'pass'},
        'policy':{r1:{'enabled':True,'rule_group':'example','priority':1},
                  r2:{'enabled':True,'rule_group':'example','priority':2}}}
    assert [r['message_id'] for r in select(conn,bundle,rt)]==[m2]


def test_blocked_measurement_cannot_be_activated_by_policy(source):
    conn,bundle=source
    rule=next(r for r in table(bundle,'coaching_rule') if r['metric_key']=='fact:96')
    rid,mid=rule['rule_id'],rule['message_id']
    rt={'source_fingerprint':bundle['manifest']['source_fingerprint'],
        'message_evaluations':{mid:'pass'},'rule_evaluations':{rid:'pass'},
        'policy':{rid:{'enabled':True,'rule_group':'example','priority':1}}}
    assert select(conn,bundle,rt)==[]
