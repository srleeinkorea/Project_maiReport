-- 운영 DB에서 최초 1회 실행. 서버 지식DB에서는 실행하지 않는다.
-- 기존 5개 테이블을 덮어쓰지 않고 별도 스키마에 버전별 후보 계약을 저장한다.
-- 재실행 시 기존 테이블 오류로 rollback한다. DROP/TRUNCATE 없음.
BEGIN;
DO $$ BEGIN
    IF current_database()='health_knowledge' THEN
        RAISE EXCEPTION 'This DDL targets the operations DB, not the canonical KDB';
    END IF;
END $$;
CREATE SCHEMA IF NOT EXISTS maireport_kdb_v1;
CREATE TABLE maireport_kdb_v1.coaching_contract_release (
    release_id text PRIMARY KEY,
    contract_version text NOT NULL CHECK (contract_version='mai_coaching_candidate/v1'),
    generated_at timestamptz NOT NULL,
    source_migration text NOT NULL,
    manifest jsonb NOT NULL,
    CHECK ((manifest->'validation_errors'='[]'::jsonb) IS TRUE),
    CHECK ((release_id=manifest->>'source_fingerprint') IS TRUE)
);
CREATE TABLE maireport_kdb_v1.coaching_input (
    release_id text NOT NULL REFERENCES maireport_kdb_v1.coaching_contract_release,
    input_key text NOT NULL,
    input_kind text NOT NULL,
    native_key text NOT NULL,
    question_text_ko text,
    freshness_hours integer,
    available_now boolean,
    adapter_owner text NOT NULL,
    PRIMARY KEY(release_id,input_key)
);
CREATE TABLE maireport_kdb_v1.coaching_metric (
    release_id text NOT NULL REFERENCES maireport_kdb_v1.coaching_contract_release,
    metric_key text NOT NULL,
    metric_kind text NOT NULL CHECK(metric_kind IN ('fact_axis','sample_observation')),
    native_target text NOT NULL,
    unit text NOT NULL,
    source_fact_seq bigint,
    recommendation_package text,
    reference_quantity jsonb,
    population jsonb,
    observation_rules jsonb NOT NULL,
    axis_event_requirements jsonb NOT NULL,
    target_bout_reference jsonb,
    sample_contract jsonb,
    alternative_groups jsonb NOT NULL,
    measurement_state text NOT NULL CHECK(measurement_state IN ('measurement_path_available','no_usable_measurement_path')),
    calculation_state text NOT NULL CHECK(calculation_state='operating_adapter_required'),
    source_ref jsonb NOT NULL,
    PRIMARY KEY(release_id,metric_key)
);
CREATE TABLE maireport_kdb_v1.coaching_metric_signal (
    release_id text NOT NULL,
    metric_key text NOT NULL,
    signal_key text NOT NULL,
    signal_unit text NOT NULL,
    signal_min numeric,
    signal_max numeric,
    min_inclusive boolean NOT NULL,
    max_inclusive boolean NOT NULL,
    source_range text,
    required_input_keys text[] NOT NULL,
    source_kind text NOT NULL,
    source_ref jsonb NOT NULL,
    selection_priority integer,
    PRIMARY KEY(release_id,metric_key,signal_key),
    FOREIGN KEY(release_id,metric_key) REFERENCES maireport_kdb_v1.coaching_metric
);
CREATE TABLE maireport_kdb_v1.coaching_message (
    release_id text NOT NULL REFERENCES maireport_kdb_v1.coaching_contract_release,
    message_id text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    population_condition text NOT NULL,
    topic text,
    audience_contracts jsonb NOT NULL CHECK(jsonb_array_length(audience_contracts)>0),
    support_claims jsonb NOT NULL CHECK(jsonb_array_length(support_claims)>0),
    context_claims jsonb NOT NULL,
    criteria_traces jsonb NOT NULL,
    gate_contracts jsonb NOT NULL,
    event_requirements jsonb NOT NULL,
    sample_requirements jsonb NOT NULL,
    candidate_state text NOT NULL CHECK(candidate_state='requires_operating_evaluation'),
    source_ref jsonb NOT NULL,
    PRIMARY KEY(release_id,message_id)
);
CREATE TABLE maireport_kdb_v1.coaching_rule (
    release_id text NOT NULL,
    rule_id text NOT NULL,
    message_id text NOT NULL,
    trigger_type text NOT NULL CHECK(trigger_type IN ('metric_range','sample_observed','context_contract')),
    metric_key text,
    source_position text CHECK(source_position IN ('below','within','above')),
    value_min numeric,
    value_max numeric,
    min_inclusive boolean NOT NULL,
    max_inclusive boolean NOT NULL,
    source_ref jsonb NOT NULL,
    all_input_keys jsonb NOT NULL,
    candidate_state text NOT NULL CHECK(candidate_state IN ('requires_operating_evaluation','blocked_no_usable_measurement_path')),
    rule_group text,
    priority integer,
    PRIMARY KEY(release_id,rule_id),
    FOREIGN KEY(release_id,message_id) REFERENCES maireport_kdb_v1.coaching_message,
    FOREIGN KEY(release_id,metric_key) REFERENCES maireport_kdb_v1.coaching_metric,
    CHECK ((trigger_type='context_contract' AND metric_key IS NULL
             AND value_min IS NULL AND value_max IS NULL)
        OR (trigger_type<>'context_contract' AND metric_key IS NOT NULL
             AND (value_min IS NOT NULL OR value_max IS NOT NULL)))
);
CREATE INDEX coaching_rule_message_idx ON maireport_kdb_v1.coaching_rule(release_id,message_id);
COMMIT;
