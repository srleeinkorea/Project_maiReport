mai-report screen set (18 screens)
svg/ : Figma import
png/ : @2x reference

01_home_default = 01_홈_기본
02_home_questions_done_coaching = 02_홈_질문완료_코칭생성
03_home_condition_observing = 03_홈_컨디션_일부관찰중
04_home_health_unlinked = 04_홈_건강데이터_미연동
05_life_goals = 05_생활_목표분석
06_life_goals_past_day = 06_생활_목표분석_지난날짜
07_life_metrics = 07_생활_지표별분석
08_life_daily_synced = 08_생활_생활분석
09_life_daily_syncing = 16_생활분석_동기화중
10_link_source_select = 17_연동_소스선택
11_link_unlink_confirm = 18_연동_해제확인
12_all_health_data_list = 09_전체건강데이터_목록
13_detail_steps_bar = 10_상세_걸음수_막대
14_detail_weight_line = 11_상세_체중_라인
15_detail_height_line = 15_상세_키_라인
16_detail_bp_point = 12_상세_혈압_포인트
17_detail_glucose_point = 13_상세_혈당_포인트
18_detail_exercise_list = 14_상세_운동기록_리스트